import { prisma } from "../src/db/client";

/** Creates a throwaway Business for one test file to use, so tests don't
 * collide with each other or with seed data. Caller is responsible for
 * calling cleanupBusiness() in an afterAll. */
export async function createTestBusiness(
  namePrefix: string,
  overrides?: { messengerPageId?: string; messengerPageAccessToken?: string }
) {
  const suffix = Math.random().toString(36).slice(2, 8);
  return prisma.business.create({
    data: {
      name: `${namePrefix} ${suffix}`,
      slug: `${namePrefix.toLowerCase().replace(/\s+/g, "-")}-${suffix}`,
      ...overrides,
    },
  });
}

/** Deletes a business and everything cascaded from it. */
export async function cleanupBusiness(businessId: string) {
  await prisma.business.delete({ where: { id: businessId } }).catch(() => {
    // already gone / never fully created — fine for test cleanup
  });
}
