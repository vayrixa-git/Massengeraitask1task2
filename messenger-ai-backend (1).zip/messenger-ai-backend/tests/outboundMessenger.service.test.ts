import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { OutboundMessengerService } from "../src/services/outboundMessenger.service";
import type { IMessengerService, MessengerSendResult } from "../src/services/messenger.service";
import { customerRepository } from "../src/repositories/customer.repository";
import { conversationRepository } from "../src/repositories/conversation.repository";
import { prisma } from "../src/db/client";
import { createTestBusiness, cleanupBusiness } from "./testUtils";

class FakeSucceedingMessenger implements IMessengerService {
  async sendMessage(): Promise<MessengerSendResult> {
    return { recipientId: "psid-outbound", providerMessageId: "mid.outbound.success" };
  }
  async sendTextMessage(): Promise<MessengerSendResult> {
    return { recipientId: "psid-outbound", providerMessageId: "mid.outbound.success" };
  }
}

class FakeFailingMessenger implements IMessengerService {
  async sendMessage(): Promise<MessengerSendResult> {
    throw new Error("simulated Graph API failure");
  }
  async sendTextMessage(): Promise<MessengerSendResult> {
    throw new Error("simulated Graph API failure");
  }
}

describe("OutboundMessengerService", () => {
  let business: Awaited<ReturnType<typeof createTestBusiness>>;
  let customerId: string;
  let conversationId: string;

  beforeAll(async () => {
    business = await createTestBusiness("Outbound Test");
    const customer = await customerRepository.findOrCreateByMessengerPsid(business.id, "psid-outbound-test");
    customerId = customer.id;
    const conversation = await conversationRepository.findOrCreateActiveForCustomer(business.id, customerId);
    conversationId = conversation.id;
  });

  afterAll(async () => {
    await cleanupBusiness(business.id);
  });

  it("persists an outbound Message row when the send succeeds", async () => {
    const service = new OutboundMessengerService(new FakeSucceedingMessenger());

    const result = await service.sendAndRecord(business.id, {
      conversationId,
      customerId,
      recipientPsid: "psid-outbound-test",
      text: "thanks for reaching out!",
      pageAccessToken: "fake-token",
    });

    expect(result.providerMessageId).toBe("mid.outbound.success");
    expect(result.message.senderType).toBe("AI");
    expect(result.message.externalMessageId).toBe("mid.outbound.success");

    const stored = await prisma.message.findUnique({ where: { id: result.message.id } });
    expect(stored).not.toBeNull();
    expect(stored?.content).toBe("thanks for reaching out!");
  });

  it("does not create a Message row when the Graph API call fails", async () => {
    const service = new OutboundMessengerService(new FakeFailingMessenger());
    const before = await prisma.message.count({ where: { businessId: business.id } });

    await expect(
      service.sendAndRecord(business.id, {
        conversationId,
        customerId,
        recipientPsid: "psid-outbound-test",
        text: "this should never be stored",
        pageAccessToken: "fake-token",
      })
    ).rejects.toThrow("simulated Graph API failure");

    const after = await prisma.message.count({ where: { businessId: business.id } });
    expect(after).toBe(before);
  });

  it("throws MissingAccessTokenError and never calls the Messenger API when no token is available", async () => {
    let called = false;
    class TrackingMessenger implements IMessengerService {
      async sendMessage(): Promise<MessengerSendResult> {
        called = true;
        return { recipientId: "x", providerMessageId: "x" };
      }
      async sendTextMessage(): Promise<MessengerSendResult> {
        called = true;
        return { recipientId: "x", providerMessageId: "x" };
      }
    }
    const service = new OutboundMessengerService(new TrackingMessenger());

    await expect(
      service.sendAndRecord(business.id, {
        conversationId,
        customerId,
        recipientPsid: "psid-outbound-test",
        text: "no token available",
        pageAccessToken: undefined,
      })
    ).rejects.toThrow();

    expect(called).toBe(false);
  });
});
