import { describe, it, expect, afterAll } from "vitest";
import { customerRepository } from "../src/repositories/customer.repository";
import { aiActionRepository } from "../src/repositories/aiAction.repository";
import { createTestBusiness, cleanupBusiness } from "./testUtils";

describe("AIAction audit trail", () => {
  let businessId: string;
  let customerId: string;

  it("records a pending action", async () => {
    const business = await createTestBusiness("AIActionTest");
    businessId = business.id;
    const customer = await customerRepository.create(businessId, { name: "Action Customer" });
    customerId = customer.id;

    const action = await aiActionRepository.record(businessId, {
      actionType: "APPLY_DISCOUNT",
      reason: "Customer requested 20% off, above the 15% auto-approve threshold",
      customerId,
      inputData: { requestedDiscountPercent: 20 },
    });

    expect(action.status).toBe("PENDING");
    expect(action.executedAt).toBeNull();
  });

  it("marks an action executed with result data", async () => {
    const action = await aiActionRepository.record(businessId, {
      actionType: "SEND_REPLY",
      reason: "Answered a delivery-time question from BusinessKnowledge",
      customerId,
    });

    const ok = await aiActionRepository.markExecuted(businessId, action.id, { replied: true });
    expect(ok).toBe(true);

    const list = await aiActionRepository.listForCustomer(businessId, customerId);
    const found = list.find((a) => a.id === action.id);
    expect(found!.status).toBe("EXECUTED");
    expect(found!.executedAt).not.toBeNull();
  });

  it("lists only pending actions for approval", async () => {
    const pending = await aiActionRepository.listPendingApproval(businessId);
    expect(pending.every((a) => a.status === "PENDING")).toBe(true);
    expect(pending.length).toBeGreaterThanOrEqual(1);
  });

  afterAll(async () => {
    await cleanupBusiness(businessId);
  });
});
