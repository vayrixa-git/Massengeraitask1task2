import crypto from "node:crypto";

/** Builds the X-Hub-Signature-256 header value the way Facebook actually
 * computes it, for tests that need a genuinely valid signature. */
export function signPayload(appSecret: string, rawBody: string): string {
  const hmac = crypto.createHmac("sha256", appSecret).update(rawBody).digest("hex");
  return `sha256=${hmac}`;
}

export function buildTextMessagePayload(
  pageId: string,
  senderPsid: string,
  text: string,
  mid: string,
  timestamp: number = Date.now()
) {
  return {
    object: "page",
    entry: [
      {
        id: pageId,
        time: timestamp,
        messaging: [
          {
            sender: { id: senderPsid },
            recipient: { id: pageId },
            timestamp,
            message: { mid, text },
          },
        ],
      },
    ],
  };
}

export function buildPostbackPayload(
  pageId: string,
  senderPsid: string,
  payload: string,
  timestamp: number = Date.now()
) {
  return {
    object: "page",
    entry: [
      {
        id: pageId,
        time: timestamp,
        messaging: [
          {
            sender: { id: senderPsid },
            recipient: { id: pageId },
            timestamp,
            postback: { payload, title: "Get Started" },
          },
        ],
      },
    ],
  };
}
