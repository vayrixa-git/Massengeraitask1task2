import { describe, it, expect, vi } from "vitest";
import { MessengerService } from "../src/services/messenger.service";
import { MessengerApiError, MissingAccessTokenError } from "../src/lib/errors";

function fakeFetchResponse(status: number, body: unknown): Response {
  return {
    ok: status >= 200 && status < 300,
    status,
    json: async () => body,
    text: async () => JSON.stringify(body),
  } as unknown as Response;
}

describe("MessengerService", () => {
  it("builds the correct Graph API request and returns the provider message id on success", async () => {
    const calls: Array<{ url: string; init: RequestInit }> = [];
    const fakeFetch = vi.fn(async (url: string, init: RequestInit) => {
      calls.push({ url, init });
      return fakeFetchResponse(200, { recipient_id: "psid-123", message_id: "mid.graph.456" });
    }) as unknown as typeof fetch;

    const service = new MessengerService(fakeFetch);
    const result = await service.sendTextMessage({
      recipientPsid: "psid-123",
      pageAccessToken: "test-page-token",
      text: "hello from the business",
    });

    expect(result).toEqual({ recipientId: "psid-123", providerMessageId: "mid.graph.456" });

    expect(calls.length).toBe(1);
    expect(calls[0].url).toContain("graph.facebook.com");
    expect(calls[0].url).toContain("access_token=test-page-token");
    const sentBody = JSON.parse(calls[0].init.body as string);
    expect(sentBody.recipient.id).toBe("psid-123");
    expect(sentBody.message.text).toBe("hello from the business");
    expect(sentBody.messaging_type).toBe("RESPONSE");
  });

  it("throws MessengerApiError and does not crash when the Graph API responds with an error status", async () => {
    const fakeFetch = vi.fn(async () => fakeFetchResponse(400, { error: { message: "Invalid parameter" } })) as unknown as typeof fetch;
    const service = new MessengerService(fakeFetch);

    await expect(
      service.sendTextMessage({ recipientPsid: "psid-x", pageAccessToken: "token-x", text: "hi" })
    ).rejects.toBeInstanceOf(MessengerApiError);
  });

  it("throws MissingAccessTokenError instead of calling fetch when no token is available", async () => {
    const fakeFetch = vi.fn() as unknown as typeof fetch;
    const service = new MessengerService(fakeFetch);

    await expect(
      service.sendTextMessage({ recipientPsid: "psid-x", pageAccessToken: undefined, text: "hi" })
    ).rejects.toBeInstanceOf(MissingAccessTokenError);
    expect(fakeFetch).not.toHaveBeenCalled();
  });
});
