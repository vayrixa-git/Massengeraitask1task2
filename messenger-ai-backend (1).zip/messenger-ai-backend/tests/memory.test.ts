import { describe, it, expect, afterAll } from "vitest";
import { customerRepository } from "../src/repositories/customer.repository";
import { memoryService } from "../src/services/memory.service";
import { memoryRepository } from "../src/repositories/memory.repository";
import { createTestBusiness, cleanupBusiness } from "./testUtils";

describe("memory lifecycle", () => {
  let businessId: string;
  let customerId: string;

  it("saves a memory", async () => {
    const business = await createTestBusiness("MemoryTest");
    businessId = business.id;
    const customer = await customerRepository.create(businessId, { name: "Memory Customer" });
    customerId = customer.id;

    const saved = await memoryService.saveMemory(businessId, {
      customerId,
      content: "Prefers matte lipstick shades",
      memoryType: "PREFERENCE",
      importance: 4,
      confidence: 0.9,
      source: "EXPLICIT_STATEMENT",
    });

    expect(saved.id).toBeTruthy();
  });

  it("retrieves relevant memories ranked by importance", async () => {
    await memoryService.saveMemory(businessId, {
      customerId,
      content: "Lives in Dhanmondi, Dhaka",
      memoryType: "FACT",
      importance: 2,
    });

    const relevant = await memoryService.getRelevantMemories(businessId, customerId, { limit: 5 });
    expect(relevant.length).toBeGreaterThanOrEqual(2);
    // highest importance first
    expect(relevant[0].importance).toBeGreaterThanOrEqual(relevant[relevant.length - 1].importance);
  });

  it("updates a memory by superseding it, keeping the old row for history", async () => {
    const original = await memoryService.saveMemory(businessId, {
      customerId,
      content: "Budget-conscious shopper",
      memoryType: "PREFERENCE",
      importance: 3,
    });

    const updated = await memoryService.updateMemory(businessId, original.id, {
      customerId,
      content: "Willing to pay premium for quality skincare",
      memoryType: "PREFERENCE",
      importance: 3,
    });

    expect(updated.id).not.toBe(original.id);

    const oldRow = await memoryRepository.findById(businessId, original.id);
    expect(oldRow!.status).toBe("SUPERSEDED");

    const newRow = await memoryRepository.findById(businessId, updated.id);
    expect(newRow!.status).toBe("ACTIVE");
    expect(newRow!.supersedesId).toBe(original.id);
  });

  it("invalidates a memory so it no longer counts as active", async () => {
    const memory = await memoryService.saveMemory(businessId, {
      customerId,
      content: "Incorrect note to be retracted",
      memoryType: "OTHER",
    });

    const ok = await memoryService.invalidateMemory(businessId, memory.id);
    expect(ok).toBe(true);

    const active = await memoryRepository.findActiveForCustomer(businessId, customerId);
    expect(active.find((m) => m.id === memory.id)).toBeUndefined();
  });

  it("builds a full customer context", async () => {
    const context = await memoryService.buildCustomerContext(businessId, customerId);
    expect(context).not.toBeNull();
    expect(context!.customer.id).toBe(customerId);
    expect(context!.activeMemories.length).toBeGreaterThan(0);
  });

  afterAll(async () => {
    await cleanupBusiness(businessId);
  });
});
