import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { webhookEventRepository } from "../src/repositories/webhookEvent.repository";
import { customerRepository } from "../src/repositories/customer.repository";
import { conversationRepository } from "../src/repositories/conversation.repository";
import { prisma } from "../src/db/client";
import { createTestBusiness, cleanupBusiness } from "./testUtils";

describe("webhookEventRepository", () => {
  let business: Awaited<ReturnType<typeof createTestBusiness>>;
  let customerId: string;
  let conversationId: string;

  beforeAll(async () => {
    business = await createTestBusiness("WebhookEvent Test");
    const customer = await customerRepository.findOrCreateByMessengerPsid(business.id, "psid-webhookevent-test");
    customerId = customer.id;
    const conversation = await conversationRepository.findOrCreateActiveForCustomer(business.id, customerId);
    conversationId = conversation.id;
  });

  afterAll(async () => {
    await cleanupBusiness(business.id);
  });

  describe("tryRecordEvent (non-message events)", () => {
    it("records a new event and returns it", async () => {
      const dedupeKey = `postback:test:${Date.now()}`;
      const recorded = await webhookEventRepository.tryRecordEvent(business.id, dedupeKey, "postback");
      expect(recorded).not.toBeNull();
      expect(recorded?.eventType).toBe("postback");
    });

    it("returns null for a dedupeKey already recorded — idempotent", async () => {
      const dedupeKey = `postback:test-dup:${Date.now()}`;
      const first = await webhookEventRepository.tryRecordEvent(business.id, dedupeKey, "postback");
      const second = await webhookEventRepository.tryRecordEvent(business.id, dedupeKey, "postback");
      expect(first).not.toBeNull();
      expect(second).toBeNull();

      const rows = await prisma.webhookEvent.findMany({ where: { businessId: business.id, dedupeKey } });
      expect(rows.length).toBe(1);
    });
  });

  describe("recordIncomingMessage", () => {
    it("creates the message, bumps conversation.lastMessageAt, and records the ledger row together", async () => {
      const dedupeKey = `mid:test-${Date.now()}`;
      const mid = `mid-repo-test-${Date.now()}`;

      const { message, created } = await webhookEventRepository.recordIncomingMessage(business.id, {
        dedupeKey,
        conversationId,
        customerId,
        content: "hello from the repo test",
        externalMessageId: mid,
      });

      expect(created).toBe(true);
      expect(message.content).toBe("hello from the repo test");
      expect(message.externalMessageId).toBe(mid);

      const conversation = await prisma.conversation.findUnique({ where: { id: conversationId } });
      expect(conversation?.lastMessageAt.getTime()).toBe(message.createdAt.getTime());

      const ledgerRow = await prisma.webhookEvent.findUnique({
        where: { businessId_dedupeKey: { businessId: business.id, dedupeKey } },
      });
      expect(ledgerRow?.messageId).toBe(message.id);
    });

    it("is idempotent: calling it again with the same dedupeKey returns the existing message instead of creating a new one", async () => {
      const dedupeKey = `mid:test-idempotent-${Date.now()}`;
      const mid = `mid-repo-idempotent-${Date.now()}`;

      const first = await webhookEventRepository.recordIncomingMessage(business.id, {
        dedupeKey,
        conversationId,
        customerId,
        content: "first delivery",
        externalMessageId: mid,
      });

      const second = await webhookEventRepository.recordIncomingMessage(business.id, {
        dedupeKey,
        conversationId,
        customerId,
        content: "first delivery",
        externalMessageId: mid,
      });

      expect(first.created).toBe(true);
      expect(second.created).toBe(false);
      expect(second.message.id).toBe(first.message.id);

      const count = await prisma.message.count({ where: { businessId: business.id, externalMessageId: mid } });
      expect(count).toBe(1);
    });
  });
});
