import { describe, it, expect, afterAll } from "vitest";
import { customerRepository } from "../src/repositories/customer.repository";
import { memoryService } from "../src/services/memory.service";
import { productRepository } from "../src/repositories/product.repository";
import { createTestBusiness, cleanupBusiness } from "./testUtils";

describe("tenant isolation", () => {
  let businessA: string;
  let businessB: string;

  it("sets up two separate businesses with their own customer", async () => {
    const a = await createTestBusiness("TenantA");
    const b = await createTestBusiness("TenantB");
    businessA = a.id;
    businessB = b.id;
  });

  it("business B cannot read business A's customer", async () => {
    const customerA = await customerRepository.create(businessA, { name: "A's Customer" });

    const foundFromB = await customerRepository.findById(businessB, customerA.id);
    expect(foundFromB).toBeNull();

    const foundFromA = await customerRepository.findById(businessA, customerA.id);
    expect(foundFromA).not.toBeNull();
  });

  it("business B cannot read or invalidate business A's memory", async () => {
    const customerA = await customerRepository.create(businessA, { name: "Memory Owner" });
    const memory = await memoryService.saveMemory(businessA, {
      customerId: customerA.id,
      content: "Sensitive note only business A should see",
    });

    const crossTenantMemories = await memoryService.getCustomerMemory(businessB, customerA.id);
    expect(crossTenantMemories.length).toBe(0);

    const invalidated = await memoryService.invalidateMemory(businessB, memory.id);
    expect(invalidated).toBe(false);

    const stillActive = await memoryService.getCustomerMemory(businessA, customerA.id);
    expect(stillActive.find((m) => m.id === memory.id)?.status).toBe("ACTIVE");
  });

  it("product SKUs are unique per business, not globally", async () => {
    const p1 = await productRepository.create(businessA, {
      name: "Shared SKU Product A",
      price: 100,
      sku: "SHARED-SKU",
    });
    const p2 = await productRepository.create(businessB, {
      name: "Shared SKU Product B",
      price: 200,
      sku: "SHARED-SKU",
    });

    expect(p1.businessId).not.toBe(p2.businessId);
    expect(p1.sku).toBe(p2.sku);
  });

  afterAll(async () => {
    await cleanupBusiness(businessA);
    await cleanupBusiness(businessB);
  });
});
