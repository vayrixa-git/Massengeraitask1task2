import { describe, it, expect, afterAll } from "vitest";
import { customerRepository } from "../src/repositories/customer.repository";
import { conversationRepository } from "../src/repositories/conversation.repository";
import { messageRepository } from "../src/repositories/message.repository";
import { createTestBusiness, cleanupBusiness } from "./testUtils";

describe("conversations and messages", () => {
  let businessId: string;
  let customerId: string;

  it("creates a conversation for a customer", async () => {
    const business = await createTestBusiness("ConvoTest");
    businessId = business.id;
    const customer = await customerRepository.create(businessId, { name: "Convo Customer" });
    customerId = customer.id;

    const conversation = await conversationRepository.create(businessId, customerId);
    expect(conversation.businessId).toBe(businessId);
    expect(conversation.customerId).toBe(customerId);
    expect(conversation.status).toBe("OPEN");
  });

  it("reuses the active conversation instead of creating a new one", async () => {
    const first = await conversationRepository.findOrCreateActiveForCustomer(businessId, customerId);
    const second = await conversationRepository.findOrCreateActiveForCustomer(businessId, customerId);
    expect(second.id).toBe(first.id);
  });

  it("stores messages and bumps lastMessageAt", async () => {
    const conversation = await conversationRepository.findOrCreateActiveForCustomer(businessId, customerId);

    const before = conversation.lastMessageAt;

    const msg = await messageRepository.create(businessId, {
      conversationId: conversation.id,
      customerId,
      senderType: "CUSTOMER",
      content: "Hello, is this in stock?",
      metadata: { mid: "test-mid-1" },
    });

    expect(msg.content).toBe("Hello, is this in stock?");

    const updated = await conversationRepository.findById(businessId, conversation.id);
    expect(updated!.lastMessageAt.getTime()).toBeGreaterThanOrEqual(before.getTime());

    const messages = await messageRepository.listForConversation(businessId, conversation.id);
    expect(messages.length).toBeGreaterThanOrEqual(1);
  });

  it("rejects a message for a conversation outside the business", async () => {
    const otherBusiness = await createTestBusiness("OtherBiz");
    const conversation = await conversationRepository.findOrCreateActiveForCustomer(businessId, customerId);

    await expect(
      messageRepository.create(otherBusiness.id, {
        conversationId: conversation.id,
        senderType: "CUSTOMER",
        content: "should not be allowed",
      })
    ).rejects.toThrow();

    await cleanupBusiness(otherBusiness.id);
  });

  afterAll(async () => {
    await cleanupBusiness(businessId);
  });
});
