import { describe, it, expect, afterAll } from "vitest";
import { customerRepository } from "../src/repositories/customer.repository";
import { createTestBusiness, cleanupBusiness } from "./testUtils";

describe("customerRepository", () => {
  let businessId: string;

  it("creates a customer", async () => {
    const business = await createTestBusiness("CustomerTest");
    businessId = business.id;

    const customer = await customerRepository.create(businessId, {
      messengerPsid: "psid-abc",
      name: "Test Customer",
      phone: "+8801700000000",
    });

    expect(customer.id).toBeTruthy();
    expect(customer.businessId).toBe(businessId);
    expect(customer.name).toBe("Test Customer");
  });

  it("finds or creates by messenger PSID idempotently", async () => {
    const first = await customerRepository.findOrCreateByMessengerPsid(businessId, "psid-xyz", {
      name: "Idempotent Customer",
    });
    const second = await customerRepository.findOrCreateByMessengerPsid(businessId, "psid-xyz", {
      name: "Should Not Overwrite",
    });

    expect(second.id).toBe(first.id);
    expect(second.name).toBe("Idempotent Customer");
  });

  afterAll(async () => {
    await cleanupBusiness(businessId);
  });
});
