import { describe, it, expect, beforeAll, afterAll } from "vitest";
import request from "supertest";
import { createApp } from "../src/app";
import { prisma } from "../src/db/client";
import { createTestBusiness, cleanupBusiness } from "./testUtils";
import { signPayload, buildTextMessagePayload, buildPostbackPayload } from "./messengerTestHelpers";

const APP_SECRET = "test-app-secret";
const VERIFY_TOKEN = "test-verify-token";

const app = createApp();

describe("Messenger webhook", () => {
  let businessA: Awaited<ReturnType<typeof createTestBusiness>>;
  let businessB: Awaited<ReturnType<typeof createTestBusiness>>;

  beforeAll(async () => {
    process.env.MESSENGER_APP_SECRET = APP_SECRET;
    process.env.MESSENGER_VERIFY_TOKEN = VERIFY_TOKEN;

    businessA = await createTestBusiness("Webhook Test A", { messengerPageId: `page-a-${Date.now()}` });
    businessB = await createTestBusiness("Webhook Test B", { messengerPageId: `page-b-${Date.now()}` });
  });

  afterAll(async () => {
    await cleanupBusiness(businessA.id);
    await cleanupBusiness(businessB.id);
    delete process.env.MESSENGER_APP_SECRET;
    delete process.env.MESSENGER_VERIFY_TOKEN;
  });

  describe("GET verification", () => {
    it("succeeds with the correct verify token and echoes the challenge", async () => {
      const res = await request(app).get("/webhooks/messenger").query({
        "hub.mode": "subscribe",
        "hub.verify_token": VERIFY_TOKEN,
        "hub.challenge": "challenge-echo-123",
      });
      expect(res.status).toBe(200);
      expect(res.text).toBe("challenge-echo-123");
    });

    it("fails with an incorrect verify token", async () => {
      const res = await request(app).get("/webhooks/messenger").query({
        "hub.mode": "subscribe",
        "hub.verify_token": "wrong-token",
        "hub.challenge": "challenge-echo-123",
      });
      expect(res.status).toBe(403);
    });
  });

  describe("POST security", () => {
    it("rejects a malformed request body", async () => {
      const res = await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", "sha256=irrelevant")
        .send("{ not valid json");
      expect(res.status).toBe(400);
    });

    it("rejects an invalid signature", async () => {
      const payload = buildTextMessagePayload(businessA.messengerPageId!, "psid-sig-test", "hello", "mid-sig-test-1");
      const raw = JSON.stringify(payload);
      const res = await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", "sha256=0000000000000000000000000000000000000000000000000000000000000000")
        .send(raw);
      expect(res.status).toBe(401);
    });

    it("rejects a missing signature header", async () => {
      const payload = buildTextMessagePayload(businessA.messengerPageId!, "psid-sig-test-2", "hello", "mid-sig-test-2");
      const res = await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .send(JSON.stringify(payload));
      expect(res.status).toBe(401);
    });

    it("never echoes the app secret or verify token back in any response", async () => {
      const res = await request(app).get("/webhooks/messenger").query({
        "hub.mode": "subscribe",
        "hub.verify_token": "wrong-token",
        "hub.challenge": "x",
      });
      expect(JSON.stringify(res.body) + res.text).not.toContain(APP_SECRET);
      expect(JSON.stringify(res.body) + res.text).not.toContain(VERIFY_TOKEN);
    });
  });

  describe("business resolution & tenant isolation", () => {
    it("resolves the correct business from a known Messenger page id", async () => {
      const psid = `psid-resolve-${Date.now()}`;
      const mid = `mid-resolve-${Date.now()}`;
      const payload = buildTextMessagePayload(businessA.messengerPageId!, psid, "hi there", mid);
      const raw = JSON.stringify(payload);

      const res = await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", signPayload(APP_SECRET, raw))
        .send(raw);

      expect(res.status).toBe(200);

      const message = await prisma.message.findFirst({ where: { businessId: businessA.id, externalMessageId: mid } });
      expect(message).not.toBeNull();
      expect(message?.content).toBe("hi there");
    });

    it("handles an unknown Messenger page safely without creating a business or crashing", async () => {
      const payload = buildTextMessagePayload("totally-unknown-page-id", "psid-unknown", "hello?", "mid-unknown-1");
      const raw = JSON.stringify(payload);

      const res = await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", signPayload(APP_SECRET, raw))
        .send(raw);

      expect(res.status).toBe(200);
      const business = await prisma.business.findUnique({ where: { messengerPageId: "totally-unknown-page-id" } });
      expect(business).toBeNull();
    });

    it("never lets business A's Messenger page resolve to business B's data", async () => {
      const psid = `psid-tenant-${Date.now()}`;
      const mid = `mid-tenant-${Date.now()}`;
      const payload = buildTextMessagePayload(businessA.messengerPageId!, psid, "tenant check", mid);
      const raw = JSON.stringify(payload);

      await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", signPayload(APP_SECRET, raw))
        .send(raw);

      const messageUnderB = await prisma.message.findFirst({ where: { businessId: businessB.id, externalMessageId: mid } });
      expect(messageUnderB).toBeNull();

      const customerUnderB = await prisma.customer.findFirst({ where: { businessId: businessB.id, messengerPsid: psid } });
      expect(customerUnderB).toBeNull();
    });
  });

  describe("customer, conversation & message pipeline", () => {
    it("creates a new customer for a new PSID, then reuses it for a second message", async () => {
      const psid = `psid-pipeline-${Date.now()}`;

      const first = buildTextMessagePayload(businessA.messengerPageId!, psid, "first message", `mid-pipeline-1-${Date.now()}`);
      const rawFirst = JSON.stringify(first);
      await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", signPayload(APP_SECRET, rawFirst))
        .send(rawFirst);

      const customerAfterFirst = await prisma.customer.findFirst({ where: { businessId: businessA.id, messengerPsid: psid } });
      expect(customerAfterFirst).not.toBeNull();

      const second = buildTextMessagePayload(businessA.messengerPageId!, psid, "second message", `mid-pipeline-2-${Date.now()}`);
      const rawSecond = JSON.stringify(second);
      await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", signPayload(APP_SECRET, rawSecond))
        .send(rawSecond);

      const customersForPsid = await prisma.customer.findMany({ where: { businessId: businessA.id, messengerPsid: psid } });
      expect(customersForPsid.length).toBe(1);

      const conversationsForCustomer = await prisma.conversation.findMany({
        where: { businessId: businessA.id, customerId: customerAfterFirst!.id },
      });
      expect(conversationsForCustomer.length).toBe(1);
      expect(conversationsForCustomer[0].lastMessageAt.getTime()).toBeGreaterThan(0);
    });
  });

  describe("webhook event deduplication", () => {
    it("processes the exact same webhook payload delivered twice without creating duplicates", async () => {
      const psid = `psid-dup-${Date.now()}`;
      const mid = `mid-dup-${Date.now()}`;
      const payload = buildTextMessagePayload(businessA.messengerPageId!, psid, "duplicate me", mid);
      const raw = JSON.stringify(payload);
      const signature = signPayload(APP_SECRET, raw);

      const firstRes = await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", signature)
        .send(raw);
      expect(firstRes.status).toBe(200);

      const secondRes = await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", signature)
        .send(raw);
      expect(secondRes.status).toBe(200);

      const messages = await prisma.message.findMany({ where: { businessId: businessA.id, externalMessageId: mid } });
      expect(messages.length).toBe(1);

      const customers = await prisma.customer.findMany({ where: { businessId: businessA.id, messengerPsid: psid } });
      expect(customers.length).toBe(1);

      const ledgerRows = await prisma.webhookEvent.findMany({ where: { businessId: businessA.id, dedupeKey: `mid:${mid}` } });
      expect(ledgerRows.length).toBe(1);
    });

    it("stays correct even when the exact same payload arrives truly concurrently (racing, not sequential)", async () => {
      const psid = `psid-race-${Date.now()}`;
      const mid = `mid-race-${Date.now()}`;
      const payload = buildTextMessagePayload(businessA.messengerPageId!, psid, "racing delivery", mid);
      const raw = JSON.stringify(payload);
      const signature = signPayload(APP_SECRET, raw);

      const send = () =>
        request(app)
          .post("/webhooks/messenger")
          .set("Content-Type", "application/json")
          .set("x-hub-signature-256", signature)
          .send(raw);

      const [resA, resB] = await Promise.all([send(), send()]);
      expect(resA.status).toBe(200);
      expect(resB.status).toBe(200);

      const messages = await prisma.message.findMany({ where: { businessId: businessA.id, externalMessageId: mid } });
      expect(messages.length).toBe(1);

      const customers = await prisma.customer.findMany({ where: { businessId: businessA.id, messengerPsid: psid } });
      expect(customers.length).toBe(1);
    });
  });

  describe("unsupported event types", () => {
    it("handles a postback event without crashing and does not create a Message", async () => {
      const psid = `psid-postback-${Date.now()}`;
      const payload = buildPostbackPayload(businessA.messengerPageId!, psid, "GET_STARTED");
      const raw = JSON.stringify(payload);

      const res = await request(app)
        .post("/webhooks/messenger")
        .set("Content-Type", "application/json")
        .set("x-hub-signature-256", signPayload(APP_SECRET, raw))
        .send(raw);

      expect(res.status).toBe(200);

      const messages = await prisma.message.findMany({ where: { businessId: businessA.id, customer: { messengerPsid: psid } } });
      expect(messages.length).toBe(0);
    });
  });
});
