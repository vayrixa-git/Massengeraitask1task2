# Messenger AI — Data & Memory Foundation

Task 1 of the Messenger AI upgrade: the production-grade database and memory
layer everything else (the AI agent, browser automation, Messenger webhook
handler, autonomous execution) will be built on top of. None of that is in
this task — only the schema, data-access layer, memory service, seed data,
tests, and this document.

## 1. Database architecture

PostgreSQL 16 + Prisma ORM. One database, multi-tenant: every business's data
lives in the same tables, isolated by a `businessId` column, not by separate
schemas or databases per tenant. This was chosen over schema-per-tenant
because it keeps migrations, indexing, and cross-tenant admin queries simple
at the scale this product is aimed at (many small businesses, not a handful
of huge ones); it can be revisited if a specific tenant ever needs physical
isolation.

## 2. Tenant isolation — how it's enforced

**Every repository method that touches business-owned data takes `businessId`
as an explicit, required first argument, and every query filters by it.**
There is no global "current tenant" context object and no reliance on
Postgres row-level security. This is deliberate: an explicit parameter is
impossible to forget silently the way an implicit context can be, and it
makes every call site's tenant scope visible at the point of use. See
`tests/tenantIsolation.test.ts` for the behavior this guarantees (a business
can never read, update, or invalidate another business's rows) and
`sandbox-verification/verify.ts` for a live confirmation against the real
database (see §7).

At the schema level, every business-owned table has a `businessId` foreign
key to `Business` with `onDelete: Cascade`, and compound indexes are led by
`businessId` (e.g. `@@index([businessId, status])`) so tenant-scoped queries
stay index-backed as data grows. `Message` also carries a denormalized
`businessId` (in addition to the `conversationId` it belongs to) specifically
so audit/analytics queries over a business's messages don't need to join
through `Conversation`.

## 3. Model overview

- **Business** — the tenant. Holds Messenger Page linkage (`messengerPageId`,
  nullable — not every business is connected yet) and timezone.
- **Customer** — one per (business, Messenger PSID). `messengerPsid` is
  unique *per business*, not globally, since PSIDs are Facebook
  Page-scoped.
- **Conversation** — groups messages for one customer; carries `status`
  (OPEN/PENDING/RESOLVED/ARCHIVED), `lastMessageAt` (bumped on every new
  message, in the same transaction as the message insert), and an optional
  AI-written `summary` for later use.
- **Message** — `senderType` distinguishes CUSTOMER/AI/HUMAN_AGENT/SYSTEM;
  `metadata` is a free-form JSON column shaped for whatever a Messenger
  webhook payload needs (mid, attachments, quick replies, delivery receipts)
  without forcing a schema change per new field Facebook adds.
- **CustomerMemory** — see §4.
- **Product / Order / OrderItem** — standard catalog + order shape.
  `Product.sku` is unique per business, not globally. `OrderItem.productId`
  is `onDelete: Restrict` — deleting a product that has order history is
  blocked at the database level; use `Product.isActive = false` to retire a
  product instead. (This has one consequence worth knowing — see §8.)
- **BusinessKnowledge** — the ground truth the AI is allowed to treat as
  reliable: pricing rules, delivery/return policy, FAQ, instructions.
  `source` distinguishes BUSINESS_OWNER-provided facts from IMPORTED or
  AI_GENERATED ones, and `priority` lets a more authoritative entry win when
  two conflict. This is deliberately separate from `CustomerMemory`, which is
  per-customer and not authoritative business fact.
- **AIAction** — the audit log. Every autonomous action gets a row *before*
  it runs (`status: PENDING`), so a future Policy Layer has something to
  attach an ALLOW/BLOCK/REQUIRE_APPROVAL decision to, and every action is
  traceable afterward: what it did, why (`reason`), what it used
  (`inputData`), and what happened (`resultData`).

## 4. Memory lifecycle

`CustomerMemory` is designed so memories don't blindly accumulate forever:

- **status**: `ACTIVE → SUPERSEDED | INVALIDATED | EXPIRED`. Only `ACTIVE`
  memories are used when building context for the AI.
- **Updating a memory never overwrites it in place.** `MemoryService.updateMemory`
  creates a new row pointing at the old one via `supersedesId`, and marks the
  old row `SUPERSEDED`. The history stays queryable (`getCustomerMemory`
  returns everything, `getRelevantMemories` only `ACTIVE`).
- **Invalidating** a memory (it turned out to be wrong, or the customer
  retracted it) sets `status: INVALIDATED` — same idea, no data is deleted.
- **Expiring**: `expiresAt` is optional; `memoryRepository.expireDueMemories`
  sweeps `ACTIVE` rows past their `expiresAt` to `EXPIRED`. This is meant to
  run periodically (a cron/job queue in a later task), not on every read.
- **importance** (1–5) and **confidence** (0–1) let a context builder or
  future ranking model weigh memories instead of treating them all equally.

`MemoryService` (`src/services/memory.service.ts`) is the only supported way
to touch `CustomerMemory` — nothing else should import `memoryRepository`
directly. It implements `saveMemory`, `updateMemory`, `invalidateMemory`,
`getRelevantMemories`, `getCustomerMemory`, and `buildCustomerContext` (the
single call an AI context-builder makes before replying: who the customer
is, what's worth remembering about them, and their recent conversation
summaries).

## 5. Semantic memory — the exact integration point

pgvector **is enabled** on this database (`CREATE EXTENSION vector`,
confirmed working — see §7), and `CustomerMemory.embedding` is a real
`vector(1536)` column. Prisma has no native vector type, so it's declared
`Unsupported("vector(1536)")` in `schema.prisma`; every read or write that
touches it goes through raw SQL (`$executeRaw`/`$queryRaw`), and that raw SQL
is confined to one file, `src/repositories/memory.repository.ts`
(`setEmbedding`, `findSimilar`). Nowhere else in the codebase touches vector
SQL directly.

On top of that, `src/services/semanticMemory.service.ts` defines a
`SemanticMemoryService` interface with `PgVectorSemanticMemoryService` (the
real, working implementation) and a `NullSemanticMemoryService` fallback.
`MemoryService.getRelevantMemories` calls it when given a query embedding,
and falls back to importance/recency ranking when no embedding is supplied
or nothing has one yet.

**What's genuinely not done yet, on purpose:** nothing populates
`embedding` — every memory's embedding is `NULL` today. Generating
embeddings requires calling an embedding model, and building that call is
part of the AI agent, which this task explicitly excludes ("do not build the
AI agent"). When that task happens, it only needs to call
`MemoryService.saveMemory({..., embedding: [...] })` or
`semanticMemoryService.upsertEmbedding(...)` — no schema change, no rewrite
of anything above the repository layer. If the eventual embedding model uses
a different dimension than 1536, that's a one-line change to the column type
and `PgVectorSemanticMemoryService`, nothing else.

An ANN index (`ivfflat` or `hnsw`) for the embedding column is intentionally
**not** created yet — an index over all-NULL data is wasted disk and its
tuning (`lists` for ivfflat) depends on how many rows will actually have
embeddings. The exact index statement is left as a comment at the bottom of
the `CustomerMemory` section in
`prisma/migrations/20260918050000_init_schema/migration.sql`, ready to
uncomment once embeddings exist.

## 6. Environment limitation: Prisma engine binaries

This is worth being precise about, because it shaped how this task was
verified.

Every `prisma` CLI operation (`validate`, `generate`, `migrate dev`, `db
push`, ...) — and Prisma Client itself, since generating its actual runtime
requires the same engine — downloads native engine binaries from
`binaries.prisma.sh` on first use. **This sandbox's network egress allowlist
does not include that domain**, so every attempt returns `403
host_not_allowed`, with no workaround: not `PRISMA_ENGINES_CHECKSUM_IGNORE_MISSING`,
not pinning an older Prisma version, not the newer driver-adapter (WASM
query engine) path — the schema-engine binary used by the CLI's own
`generate`/`validate`/`migrate` commands is still fetched the same way
regardless of the Client's runtime engine choice.

**This is a restriction on this one sandbox's outbound network, not a real
constraint on the code or on where it will run.** `binaries.prisma.sh` is
Prisma's normal, standard CDN — any real machine with ordinary internet
access (a laptop, a CI runner, a Render/Railway/Fly instance, GitHub
Codespaces) reaches it with zero issues, and this is exactly the kind of
environment this project will actually be deployed to (Render, per the
existing plan for the AI Business Manager project this backend serves).

**What this meant in practice for this task:**

- `prisma/schema.prisma` and every file under `src/` and `tests/` are
  written exactly as they should be for real use, against the standard
  `@prisma/client` API. **No workaround code was added to the application
  itself** — nothing here is different because of this sandbox.
- The migration SQL
  (`prisma/migrations/20260918050000_init_schema/migration.sql`) was
  hand-authored to match `schema.prisma` exactly, then **applied for real**
  with `psql` against a real, running PostgreSQL 16 + pgvector instance in
  this sandbox (`apt-get install postgresql postgresql-16-pgvector`) — this
  is not a paper design, the tables genuinely exist and were queried.
- Since `@prisma/client`'s generated runtime doesn't exist here, the actual
  Vitest suite in `tests/` (which imports the repositories, which import
  `@prisma/client`) cannot execute in this sandbox. It's still what you
  should run — `npm test` will work normally once `npm install` runs
  somewhere with normal network access, because `prisma generate` runs
  automatically as an npm postinstall step.
- To still verify the schema and every important behavior for real *in this
  sandbox*, `sandbox-verification/verify.ts` exercises the same operations
  (tenant isolation, memory supersede/invalidate/expire, pgvector cosine
  search, per-business-unique SKUs, order items, AI action audit trail,
  cascade deletes) directly against the live database using the plain `pg`
  driver, which needs no engine binary. It is **not part of the
  application** — it's a one-time proof, kept for transparency, and safe to
  delete. Results in §7.

**What you need to do differently because of this: nothing.** Run
`npm install`, `npx prisma generate`, `npx prisma migrate resolve --applied
20260918050000_init_schema` (to tell Prisma's migration history this one was
already applied by hand — see the comment at the top of that migration's
SQL), then `npm test`, in any environment with normal internet access.

## 7. Verification results (this sandbox)

```
node --version   → v22.22.2
PostgreSQL       → 16.10, pgvector 0.6.0, extension enabled on `messenger_ai`
Migration        → applied via psql, 0 errors, all 10 tables + all indexes + FKs created
Boot check       → not run via `src/index.ts` (needs @prisma/client — see §6);
                    connectivity + pgvector confirmed via sandbox-verification/verify.ts instead
Seed data        → applied (raw-SQL equivalent of prisma/seed.ts — see §6);
                    Rangoli Cosmetics business, 3 products, 3 customers,
                    3 conversations, 4 messages, 3 memories, 1 order, 2 AI actions
sandbox-verification/verify.ts → 13/13 checks passed:
  - message creation bumps conversation.lastMessageAt
  - tenant isolation (business B cannot read business A's customer)
  - memory supersede (old row → SUPERSEDED, new row ACTIVE, supersedesId set)
  - memory invalidate (excluded from ACTIVE set)
  - memory expire (past expiresAt → EXPIRED)
  - pgvector cosine similarity returns the nearer vector first
  - Product.sku unique per business, duplicate within same business rejected
  - OrderItem correctly linked to Order + Product
  - AIAction recorded PENDING, then marked EXECUTED with resultData + executedAt
  - cascading a Business delete removes its customers, memories, and AI actions
```

## 8. Known limitations / things left for later, on purpose

- **Full tenant hard-deletion needs Orders cleared first.**
  `OrderItem.productId` is `onDelete: Restrict` (protects order history from
  an accidental single-product delete). If a business has any orders, a
  cascading `DELETE FROM "Business"` will hit that RESTRICT before Postgres
  finishes cascading through `Order → OrderItem`, because RESTRICT is
  checked immediately, not deferred. In practice this should rarely matter —
  most SaaS products deactivate a tenant rather than hard-delete it — but a
  real "delete this business" admin action needs to delete `OrderItem`/
  `Order` explicitly before deleting `Business` (see
  `sandbox-verification/verify.ts` §8 for the exact order that works).
- **No ANN index on `embedding` yet** — see §5.
- ~~No HTTP server / Messenger webhook handler~~ — **added in Task 2**, see
  `docs/MESSENGER_WEBHOOK.md` and `docs/TASK2_REPORT.md`.
- **No Policy Layer** — `AIAction.status` supports it (`PENDING` →
  `APPROVED`/`REJECTED`/`EXECUTED`/`FAILED`/`BLOCKED`), but nothing writes
  policy decisions yet; that's the AI Business Manager Policy Layer, a
  separate piece of work.
