# Messenger Webhook + Real-Time Message Pipeline (Task 2)

This covers the Messenger communication and message-ingestion layer built on
top of the Task 1 foundation (see `docs/ARCHITECTURE.md`). It does **not**
cover AI behavior — no LLM is called anywhere in this layer; see "Not yet
implemented" at the end.

## What this adds

```
Facebook Messenger
  → GET/POST /webhooks/messenger   (src/routes/messengerWebhook.routes.ts)
  → MessengerWebhookService        (src/services/messengerWebhook.service.ts)
      → BusinessResolverService      Messenger Page ID → Business
      → customerRepository           PSID → Customer (get-or-create)
      → conversationRepository       → active Conversation (get-or-create)
      → webhookEventRepository       idempotent Message + ledger write
      → AIPipelineHook                Task 3's plug-in seam (no-op for now)

AI/System (later)
  → OutboundMessengerService (src/services/outboundMessenger.service.ts)
      → MessengerService              Graph API call (src/services/messenger.service.ts)
      → messageRepository             persists the outbound Message row
```

## Environment variables

Set these in `.env` (see `.env.example` for the full block with comments):

| Variable | Scope | Purpose |
|---|---|---|
| `MESSENGER_VERIFY_TOKEN` | App-level | Checked during the one-time GET webhook verification handshake. Any string you choose — must match what you enter in the Meta App dashboard. |
| `MESSENGER_APP_SECRET` | App-level | Verifies the `X-Hub-Signature-256` header on every POST. From App Dashboard → Settings → Basic. **Never logged.** If unset, signature verification is skipped — a documented local-dev-only fallback; every real deployment must set this. |
| `MESSENGER_ACCESS_TOKEN` | Local-dev fallback | Used only when a `Business` row has no `messengerPageAccessToken` of its own. |
| `PORT` | Server | HTTP port for `src/server.ts`. Defaults to 3000. |

Per-tenant: each `Business` row has its own `messengerPageId` (which Page
webhook events arrive from) and `messengerPageAccessToken` (the token used to
send messages back to that Page). This is standard Messenger Platform
architecture: one Meta App + one App Secret can be subscribed to many Pages,
each with its own Page Access Token.

## Local development

1. **Start Postgres and apply migrations** (see `docs/ARCHITECTURE.md` for
   the pgvector requirement):
   ```
   npm run prisma:migrate:deploy
   npm run db:seed
   ```
   The seeded business (`Rangoli Cosmetics`) has `messengerPageId:
   "demo-page-123456"` and a placeholder `messengerPageAccessToken` — real
   enough to drive the webhook pipeline end-to-end locally, but not a real
   Graph API token, so outbound sends against it will fail against the real
   Facebook API until you swap in a real one (`prisma studio` is the
   quickest way to edit it).

2. **Set env vars** — copy `.env.example` to `.env` and fill in
   `MESSENGER_VERIFY_TOKEN` / `MESSENGER_APP_SECRET` (any values for local
   testing; they just need to match what you sign requests with below).

3. **Run the server**:
   ```
   npm run dev:server
   ```

4. **Test the GET verification handshake**:
   ```
   curl "http://localhost:3000/webhooks/messenger?hub.mode=subscribe&hub.verify_token=YOUR_TOKEN&hub.challenge=12345"
   ```
   Should return `12345` with a 200. This is also exactly what Meta's servers
   do once, when you first register the webhook URL in the App dashboard.

5. **Send a sample incoming message** (signature required if
   `MESSENGER_APP_SECRET` is set):
   ```bash
   BODY='{"object":"page","entry":[{"id":"demo-page-123456","time":1700000000000,"messaging":[{"sender":{"id":"test-psid-1"},"recipient":{"id":"demo-page-123456"},"timestamp":1700000000000,"message":{"mid":"mid.test.1","text":"Hello!"}}]}]}'
   SIG=$(node -e "console.log('sha256='+require('crypto').createHmac('sha256', process.env.MESSENGER_APP_SECRET).update(process.env.BODY).digest('hex'))")
   curl -X POST http://localhost:3000/webhooks/messenger \
     -H "Content-Type: application/json" \
     -H "x-hub-signature-256: $SIG" \
     -d "$BODY"
   ```
   Check it landed: `npm run prisma:studio` → Message table, or query by
   `externalMessageId = "mid.test.1"`.

6. **Test duplicate delivery** — run the exact same `curl` command again.
   Still 200, but no second Customer/Conversation/Message is created (see
   `tests/messengerWebhook.http.test.ts` "webhook event deduplication" for
   the automated version of this, including a genuinely concurrent case).

7. **Test outbound sending** — this needs a real Page Access Token (Meta App
   Dashboard → your Page → generate token), set on the seeded business:
   ```ts
   // one-off script, or via prisma studio
   await prisma.business.update({
     where: { slug: "rangoli-cosmetics" },
     data: { messengerPageAccessToken: "<real token>" },
   });
   ```
   Then, from a script or REPL:
   ```ts
   import { outboundMessengerService } from "./src/services/outboundMessenger.service";
   await outboundMessengerService.sendAndRecord(businessId, {
     conversationId, customerId,
     recipientPsid: "<a real PSID that has messaged your Page>",
     text: "Hello from the backend!",
     pageAccessToken: "<real token>",
   });
   ```
   `tests/messenger.service.test.ts` and `tests/outboundMessenger.service.test.ts`
   cover this with a fake Graph API — no real credentials or network calls
   needed to run the test suite.

8. **Public HTTPS tunnel** (only needed to receive *real* webhook traffic
   from Facebook, not for anything above): any HTTPS tunnel that forwards to
   `localhost:3000` works — this codebase has no dependency on which one you
   use. Point the Meta App's webhook URL at `https://<your-tunnel>/webhooks/messenger`.

## Webhook response codes, and why

Every response Facebook gets back is a deliberate signal about whether it
should retry:

| Status | When | Retried? |
|---|---|---|
| 200 | Verified / processed / duplicate / unknown page / unsupported event / missing sender | No — nothing to gain from a retry in any of these cases |
| 400 | Malformed JSON body | No — retrying the same bytes won't parse any better |
| 401 | Missing or invalid `X-Hub-Signature-256` | No — retrying won't produce a valid signature |
| 403 | GET verification handshake failed | N/A — this only happens once, at setup |
| 404 | `object !== "page"` | No — this server will never understand it |
| 500 | Unexpected/internal failure (e.g. a DB outage) | **Yes, intentionally** — Facebook's own retry is what recovers once the underlying issue clears, and that's safe here specifically because processing is idempotent (`WebhookEvent` ledger + the unique `Message.externalMessageId` constraint) |

## Security

- **Signature verification**: `src/lib/messengerSignature.ts` — HMAC-SHA256
  over the raw request body, compared with `crypto.timingSafeEqual`.
- **Tenant isolation**: the Business is resolved from the *verified* payload's
  Page ID, never from anything in the request body/headers that a client
  could set (there is no `businessId` field trusted from the request at
  all — see `tests/messengerWebhook.http.test.ts` "tenant isolation").
- **Secrets**: `MESSENGER_APP_SECRET`, `MESSENGER_ACCESS_TOKEN`, and
  `Business.messengerPageAccessToken` are never logged. `src/lib/logger.ts`
  callers only ever pass ids/enums; grep the codebase for `logger.` calls to
  confirm none carry a token or full payload.
- **No stack traces externally**: `src/app.ts`'s error handler and every
  webhook response path return a fixed message/status, never `err.stack` or
  `err.message` from an unexpected failure.

## Idempotency, precisely

See the file header comment in `src/repositories/webhookEvent.repository.ts`
for the full reasoning. Short version: a DB unique constraint (not an
app-level check) is what makes duplicate/concurrent webhook delivery safe,
and the Message row + the ledger row are written in one transaction so a
crash mid-processing can never mark an event "already handled" without the
message actually existing.

## Not yet implemented (intentionally — see `docs/TASK2_REPORT.md`)

No LLM integration, AI intent detection, memory extraction, RAG, sales/
shopping AI, autonomous follow-up/decision-making, or browser/computer
automation. Task 2 ends at `AIPipelineHook.onIncomingMessage` — a real
implementation of that interface is Task 3.
