import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

/**
 * Seed data reuses the fictional Bangladesh F-commerce cosmetics business
 * and product catalog already established for the AI Business Manager
 * project (same product names/prices/stock as the HTML prototype), so this
 * backend's dev data lines up with that project instead of inventing an
 * unrelated fixture business.
 */
async function main() {
  console.log("Seeding...");

  const business = await prisma.business.create({
    data: {
      name: "Rangoli Cosmetics",
      slug: "rangoli-cosmetics",
      timezone: "Asia/Dhaka",
      messengerPageId: "demo-page-123456",
      // Placeholder only — not a real Graph API token, so outbound sends
      // using it will fail against the real Facebook API. Swap in a real
      // Page Access Token (or rely on MESSENGER_ACCESS_TOKEN's fallback) to
      // actually test sending — see docs/MESSENGER_WEBHOOK.md.
      messengerPageAccessToken: "demo-page-access-token-placeholder",
    },
  });

  const [lipstick, faceWash, kajol] = await Promise.all([
    prisma.product.create({
      data: {
        businessId: business.id,
        name: "ম্যাট লিপস্টিক",
        description: "Long-lasting matte lipstick",
        price: 450,
        currency: "BDT",
        sku: "LIP-MATTE-01",
        stockQuantity: 3,
      },
    }),
    prisma.product.create({
      data: {
        businessId: business.id,
        name: "ফেসওয়াশ",
        description: "Daily brightening face wash",
        price: 350,
        currency: "BDT",
        sku: "FACE-WASH-01",
        stockQuantity: 20,
      },
    }),
    prisma.product.create({
      data: {
        businessId: business.id,
        name: "কাজল",
        description: "Smudge-proof kajol",
        price: 150,
        currency: "BDT",
        sku: "KAJOL-01",
        stockQuantity: 0,
      },
    }),
  ]);

  await prisma.businessKnowledge.createMany({
    data: [
      {
        businessId: business.id,
        type: "DELIVERY_POLICY",
        source: "BUSINESS_OWNER",
        title: "Delivery inside Dhaka",
        content: "Delivery within Dhaka takes 1-2 business days, cash on delivery available.",
        priority: 10,
      },
      {
        businessId: business.id,
        type: "RETURN_POLICY",
        source: "BUSINESS_OWNER",
        title: "Returns",
        content: "Unused items in original packaging can be returned within 7 days.",
        priority: 10,
      },
      {
        businessId: business.id,
        type: "FAQ",
        source: "BUSINESS_OWNER",
        title: "Payment methods",
        content: "We accept bKash, Nagad, and cash on delivery.",
        priority: 5,
      },
    ],
  });

  const customerNames: Array<{ name: string; psid: string; phone: string }> = [
    { name: "Nusrat Jahan", psid: "psid-1001", phone: "+8801710000001" },
    { name: "Rakibul Islam", psid: "psid-1002", phone: "+8801710000002" },
    { name: "Farhana Akter", psid: "psid-1003", phone: "+8801710000003" },
  ];

  for (const c of customerNames) {
    const customer = await prisma.customer.create({
      data: {
        businessId: business.id,
        messengerPsid: c.psid,
        name: c.name,
        phone: c.phone,
      },
    });

    const conversation = await prisma.conversation.create({
      data: {
        businessId: business.id,
        customerId: customer.id,
        status: "OPEN",
      },
    });

    const m1 = await prisma.message.create({
      data: {
        businessId: business.id,
        conversationId: conversation.id,
        customerId: customer.id,
        senderType: "CUSTOMER",
        content: `আসসালামু আলাইকুম, ${lipstick.name} এর দাম কত?`,
        metadata: { mid: `mid-${c.psid}-1`, platform: "messenger" },
      },
    });
    const m2 = await prisma.message.create({
      data: {
        businessId: business.id,
        conversationId: conversation.id,
        customerId: customer.id,
        senderType: "AI",
        content: `ওয়ালাইকুম আসসালাম! ${lipstick.name} এর দাম ${lipstick.price} টাকা।`,
        metadata: { mid: `mid-${c.psid}-2` },
      },
    });

    await prisma.conversation.update({
      where: { id: conversation.id },
      data: { lastMessageAt: m2.createdAt },
    });

    await prisma.customerMemory.create({
      data: {
        businessId: business.id,
        customerId: customer.id,
        content: `Asked about ${lipstick.name} pricing`,
        memoryType: "PURCHASE_INTENT",
        importance: 3,
        confidence: 0.9,
        source: "CONVERSATION_SUMMARY",
      },
    });

    void m1; // referenced for readability of the seed's conversation flow
  }

  // One customer with an order, to seed Order/OrderItem
  const buyer = await prisma.customer.findFirstOrThrow({
    where: { businessId: business.id, name: "Nusrat Jahan" },
  });
  const order = await prisma.order.create({
    data: {
      businessId: business.id,
      customerId: buyer.id,
      status: "CONFIRMED",
      totalAmount: 450,
      currency: "BDT",
    },
  });
  await prisma.orderItem.create({
    data: {
      orderId: order.id,
      productId: lipstick.id,
      quantity: 1,
      unitPrice: lipstick.price,
    },
  });

  await prisma.aIAction.create({
    data: {
      businessId: business.id,
      customerId: buyer.id,
      actionType: "SEND_REPLY",
      status: "EXECUTED",
      reason: "Answered a pricing question using BusinessKnowledge + Product data",
      inputData: { question: `${lipstick.name} price?` },
      resultData: { replied: true },
      executedAt: new Date(),
    },
  });

  await prisma.aIAction.create({
    data: {
      businessId: business.id,
      customerId: buyer.id,
      actionType: "APPLY_DISCOUNT",
      status: "PENDING",
      reason: "Customer asked for a bulk discount above the 15% auto-approve threshold",
      inputData: { requestedDiscountPercent: 25 },
    },
  });

  console.log(`Seeded business ${business.name} (${business.id}) with ${customerNames.length} customers, 3 products, 1 order, 2 AI actions.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
