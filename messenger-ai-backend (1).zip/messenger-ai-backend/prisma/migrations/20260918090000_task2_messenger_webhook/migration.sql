-- Task 2 — Messenger webhook + real-time message pipeline
-- Adds, additively, on top of the Task 1 schema:
--   1. Business.messengerPageAccessToken — per-tenant Page Access Token for
--      outbound sends (MESSENGER_APP_SECRET/MESSENGER_VERIFY_TOKEN stay
--      app-level env vars; this is the one thing that's genuinely per-Page).
--   2. Message.externalMessageId (+ unique index on businessId+that column) —
--      the Messenger "mid" for inbound messages / Graph API message id for
--      outbound sends. This is the idempotency key.
--   3. WebhookEvent — an idempotency ledger so every inbound webhook event
--      (not just ones that produce a Message — postback/delivery/read too)
--      can be deduplicated exactly once, atomically, via a DB unique
--      constraint rather than an app-level check-then-act race.
--
-- Hand-authored to match prisma/schema.prisma exactly — see
-- docs/ARCHITECTURE.md "Environment limitation: Prisma engine binaries" for
-- why (that limitation applies in this session's sandbox too; no Postgres
-- instance or `prisma generate` was reachable here either — see
-- docs/TASK2_REPORT.md "Verification" for exactly what was and wasn't run).
-- Purely additive: no existing column/table is altered or dropped, so Task 1
-- data and every Task 1 test remain valid against this schema unchanged.
--
-- Once applied (by hand here, or via `prisma migrate deploy` anywhere with
-- normal network access), run:
--   npx prisma migrate resolve --applied 20260918090000_task2_messenger_webhook
-- to bring Prisma's migration history table in sync.

-- 1. Business: per-tenant Page Access Token
ALTER TABLE "Business" ADD COLUMN "messengerPageAccessToken" TEXT;

-- 2. Message: external/provider message id, unique per business
ALTER TABLE "Message" ADD COLUMN "externalMessageId" TEXT;
CREATE UNIQUE INDEX "Message_businessId_externalMessageId_key" ON "Message"("businessId", "externalMessageId");

-- 3. WebhookEvent: idempotency ledger
CREATE TABLE "WebhookEvent" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "dedupeKey" TEXT NOT NULL,
    "eventType" TEXT NOT NULL,
    "messageId" TEXT,
    "processedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "WebhookEvent_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "WebhookEvent_businessId_dedupeKey_key" ON "WebhookEvent"("businessId", "dedupeKey");
CREATE INDEX "WebhookEvent_businessId_idx" ON "WebhookEvent"("businessId");
ALTER TABLE "WebhookEvent" ADD CONSTRAINT "WebhookEvent_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "WebhookEvent" ADD CONSTRAINT "WebhookEvent_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES "Message"("id") ON DELETE SET NULL ON UPDATE CASCADE;
