-- Messenger AI — initial schema
-- Hand-authored to match prisma/schema.prisma exactly (see docs/ARCHITECTURE.md
-- for why this was applied directly with psql instead of `prisma migrate dev`
-- in this environment). This is standard, idempotent-on-fresh-db DDL — running
-- `prisma migrate resolve --applied 20260918050000_init_schema` once real
-- network access to binaries.prisma.sh is available will bring Prisma's
-- migration history table in sync with zero schema drift.

CREATE EXTENSION IF NOT EXISTS vector;

-- Enums
CREATE TYPE "ConversationStatus" AS ENUM ('OPEN', 'PENDING', 'RESOLVED', 'ARCHIVED');
CREATE TYPE "SenderType" AS ENUM ('CUSTOMER', 'AI', 'HUMAN_AGENT', 'SYSTEM');
CREATE TYPE "MemoryType" AS ENUM ('PREFERENCE', 'FACT', 'LIFE_EVENT', 'COMPLAINT', 'PURCHASE_INTENT', 'CONTACT_INFO', 'OTHER');
CREATE TYPE "MemorySource" AS ENUM ('EXPLICIT_STATEMENT', 'INFERRED', 'CONVERSATION_SUMMARY', 'MANUAL_ENTRY', 'ORDER_HISTORY');
CREATE TYPE "MemoryStatus" AS ENUM ('ACTIVE', 'SUPERSEDED', 'INVALIDATED', 'EXPIRED');
CREATE TYPE "OrderStatus" AS ENUM ('PENDING', 'CONFIRMED', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'REFUNDED');
CREATE TYPE "KnowledgeType" AS ENUM ('PRODUCT_INFO', 'PRICING_RULE', 'DELIVERY_POLICY', 'RETURN_POLICY', 'FAQ', 'BUSINESS_INSTRUCTION');
CREATE TYPE "KnowledgeSource" AS ENUM ('BUSINESS_OWNER', 'IMPORTED', 'AI_GENERATED');
CREATE TYPE "AIActionStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'EXECUTED', 'FAILED', 'BLOCKED');

-- Business
CREATE TABLE "Business" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "timezone" TEXT NOT NULL DEFAULT 'Asia/Dhaka',
    "messengerPageId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Business_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Business_slug_key" ON "Business"("slug");
CREATE UNIQUE INDEX "Business_messengerPageId_key" ON "Business"("messengerPageId");
CREATE INDEX "Business_slug_idx" ON "Business"("slug");

-- Customer
CREATE TABLE "Customer" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "messengerPsid" TEXT,
    "name" TEXT,
    "phone" TEXT,
    "email" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Customer_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Customer_businessId_messengerPsid_key" ON "Customer"("businessId", "messengerPsid");
CREATE INDEX "Customer_businessId_idx" ON "Customer"("businessId");
CREATE INDEX "Customer_businessId_phone_idx" ON "Customer"("businessId", "phone");
CREATE INDEX "Customer_businessId_email_idx" ON "Customer"("businessId", "email");
ALTER TABLE "Customer" ADD CONSTRAINT "Customer_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Conversation
CREATE TABLE "Conversation" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "status" "ConversationStatus" NOT NULL DEFAULT 'OPEN',
    "summary" TEXT,
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastMessageAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Conversation_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Conversation_businessId_idx" ON "Conversation"("businessId");
CREATE INDEX "Conversation_businessId_customerId_idx" ON "Conversation"("businessId", "customerId");
CREATE INDEX "Conversation_businessId_status_idx" ON "Conversation"("businessId", "status");
CREATE INDEX "Conversation_businessId_lastMessageAt_idx" ON "Conversation"("businessId", "lastMessageAt");
ALTER TABLE "Conversation" ADD CONSTRAINT "Conversation_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Conversation" ADD CONSTRAINT "Conversation_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Message
CREATE TABLE "Message" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "conversationId" TEXT NOT NULL,
    "customerId" TEXT,
    "senderType" "SenderType" NOT NULL,
    "content" TEXT NOT NULL,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Message_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Message_businessId_idx" ON "Message"("businessId");
CREATE INDEX "Message_conversationId_createdAt_idx" ON "Message"("conversationId", "createdAt");
CREATE INDEX "Message_businessId_customerId_idx" ON "Message"("businessId", "customerId");
ALTER TABLE "Message" ADD CONSTRAINT "Message_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Message" ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Message" ADD CONSTRAINT "Message_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- CustomerMemory
CREATE TABLE "CustomerMemory" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "memoryType" "MemoryType" NOT NULL DEFAULT 'OTHER',
    "importance" INTEGER NOT NULL DEFAULT 3,
    "confidence" DOUBLE PRECISION NOT NULL DEFAULT 0.8,
    "source" "MemorySource" NOT NULL DEFAULT 'EXPLICIT_STATEMENT',
    "status" "MemoryStatus" NOT NULL DEFAULT 'ACTIVE',
    "embedding" vector(1536),
    "supersedesId" TEXT,
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "CustomerMemory_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "CustomerMemory_supersedesId_key" ON "CustomerMemory"("supersedesId");
CREATE INDEX "CustomerMemory_businessId_idx" ON "CustomerMemory"("businessId");
CREATE INDEX "CustomerMemory_businessId_customerId_status_idx" ON "CustomerMemory"("businessId", "customerId", "status");
CREATE INDEX "CustomerMemory_businessId_customerId_memoryType_idx" ON "CustomerMemory"("businessId", "customerId", "memoryType");
CREATE INDEX "CustomerMemory_expiresAt_idx" ON "CustomerMemory"("expiresAt");
ALTER TABLE "CustomerMemory" ADD CONSTRAINT "CustomerMemory_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CustomerMemory" ADD CONSTRAINT "CustomerMemory_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "CustomerMemory" ADD CONSTRAINT "CustomerMemory_supersedesId_fkey" FOREIGN KEY ("supersedesId") REFERENCES "CustomerMemory"("id") ON DELETE SET NULL ON UPDATE CASCADE;
-- Optional ANN index for embedding similarity search — created once embeddings
-- are actually populated by a later task (an empty ivfflat index is wasteful
-- and its "lists" parameter should be tuned to row count; see ARCHITECTURE.md).
-- CREATE INDEX "CustomerMemory_embedding_idx" ON "CustomerMemory" USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Product
CREATE TABLE "Product" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "price" DECIMAL(12,2) NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'BDT',
    "sku" TEXT,
    "stockQuantity" INTEGER NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Product_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Product_businessId_sku_key" ON "Product"("businessId", "sku");
CREATE INDEX "Product_businessId_idx" ON "Product"("businessId");
CREATE INDEX "Product_businessId_isActive_idx" ON "Product"("businessId", "isActive");
ALTER TABLE "Product" ADD CONSTRAINT "Product_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Order
CREATE TABLE "Order" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "status" "OrderStatus" NOT NULL DEFAULT 'PENDING',
    "totalAmount" DECIMAL(12,2) NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'BDT',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Order_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Order_businessId_idx" ON "Order"("businessId");
CREATE INDEX "Order_businessId_customerId_idx" ON "Order"("businessId", "customerId");
CREATE INDEX "Order_businessId_status_idx" ON "Order"("businessId", "status");
ALTER TABLE "Order" ADD CONSTRAINT "Order_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Order" ADD CONSTRAINT "Order_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- OrderItem
CREATE TABLE "OrderItem" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "unitPrice" DECIMAL(12,2) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "OrderItem_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OrderItem_orderId_idx" ON "OrderItem"("orderId");
CREATE INDEX "OrderItem_productId_idx" ON "OrderItem"("productId");
ALTER TABLE "OrderItem" ADD CONSTRAINT "OrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "OrderItem" ADD CONSTRAINT "OrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES "Product"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- BusinessKnowledge
CREATE TABLE "BusinessKnowledge" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "type" "KnowledgeType" NOT NULL,
    "source" "KnowledgeSource" NOT NULL DEFAULT 'BUSINESS_OWNER',
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "priority" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "BusinessKnowledge_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "BusinessKnowledge_businessId_idx" ON "BusinessKnowledge"("businessId");
CREATE INDEX "BusinessKnowledge_businessId_type_isActive_idx" ON "BusinessKnowledge"("businessId", "type", "isActive");
ALTER TABLE "BusinessKnowledge" ADD CONSTRAINT "BusinessKnowledge_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AIAction
CREATE TABLE "AIAction" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "customerId" TEXT,
    "conversationId" TEXT,
    "actionType" TEXT NOT NULL,
    "status" "AIActionStatus" NOT NULL DEFAULT 'PENDING',
    "reason" TEXT NOT NULL,
    "inputData" JSONB NOT NULL DEFAULT '{}',
    "resultData" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "executedAt" TIMESTAMP(3),
    CONSTRAINT "AIAction_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "AIAction_businessId_idx" ON "AIAction"("businessId");
CREATE INDEX "AIAction_businessId_status_idx" ON "AIAction"("businessId", "status");
CREATE INDEX "AIAction_businessId_customerId_idx" ON "AIAction"("businessId", "customerId");
CREATE INDEX "AIAction_businessId_actionType_idx" ON "AIAction"("businessId", "actionType");
CREATE INDEX "AIAction_conversationId_idx" ON "AIAction"("conversationId");
ALTER TABLE "AIAction" ADD CONSTRAINT "AIAction_businessId_fkey" FOREIGN KEY ("businessId") REFERENCES "Business"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "AIAction" ADD CONSTRAINT "AIAction_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "AIAction" ADD CONSTRAINT "AIAction_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE SET NULL ON UPDATE CASCADE;
