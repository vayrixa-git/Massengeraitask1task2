import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    globals: true,
    testTimeout: 20000,
    hookTimeout: 20000,
    // Tests run sequentially against one shared Postgres instance —
    // parallel workers would race on tenant-isolation fixtures.
    fileParallelism: false,
  },
});
