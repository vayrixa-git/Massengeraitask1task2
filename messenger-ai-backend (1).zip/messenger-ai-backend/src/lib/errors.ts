/**
 * Small typed error hierarchy. Callers (route handlers) catch AppError to
 * decide the HTTP response; anything else is treated as an unexpected
 * failure and answered with a generic message — never a stack trace or raw
 * error string — per requirement 14 (error handling) / 10 (security).
 */
export class AppError extends Error {
  public readonly statusCode: number;
  public readonly code: string;

  constructor(message: string, statusCode = 500, code = "INTERNAL_ERROR") {
    super(message);
    this.name = new.target.name;
    this.statusCode = statusCode;
    this.code = code;
  }
}

export class MissingAccessTokenError extends AppError {
  constructor(businessId: string) {
    super(`No Messenger page access token configured for business ${businessId}`, 500, "MISSING_ACCESS_TOKEN");
  }
}

export class MessengerApiError extends AppError {
  constructor(status: number) {
    super(`Messenger Graph API request failed with status ${status}`, 502, "MESSENGER_API_ERROR");
  }
}
