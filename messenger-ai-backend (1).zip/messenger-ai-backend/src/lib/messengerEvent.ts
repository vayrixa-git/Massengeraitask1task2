import type { MessengerEventType, MessengerMessagingEvent } from "../types/messenger";

/** message > postback > delivery > read > unsupported, by which key is present. */
export function classifyMessagingEvent(event: MessengerMessagingEvent): MessengerEventType {
  if (event.message) return "message";
  if (event.postback) return "postback";
  if (event.delivery) return "delivery";
  if (event.read) return "read";
  return "unsupported";
}

/**
 * The idempotency key stored on WebhookEvent.dedupeKey. Message events use
 * Messenger's own "mid" (globally unique, exactly what redelivery repeats
 * verbatim). The other event types have no id from Facebook at all, so a
 * composite of sender + timestamp + the one distinguishing field is the best
 * available substitute — good enough to dedupe exact-payload redelivery
 * (the actual failure mode that motivates this), not a cryptographic
 * guarantee against a sender able to fabricate collisions.
 */
export function buildDedupeKey(event: MessengerMessagingEvent, eventType: MessengerEventType): string {
  if (eventType === "message" && event.message?.mid) {
    return `mid:${event.message.mid}`;
  }

  const senderId = event.sender?.id ?? "unknown-sender";
  const timestamp = event.timestamp ?? 0;

  switch (eventType) {
    case "postback":
      return `postback:${senderId}:${timestamp}:${event.postback?.payload ?? ""}`;
    case "delivery":
      // A delivery event covers a range of mids; its watermark identifies
      // the batch and is stable across redelivery of the same event.
      return `delivery:${senderId}:${event.delivery?.watermark ?? timestamp}`;
    case "read":
      return `read:${senderId}:${event.read?.watermark ?? timestamp}`;
    default:
      return `unsupported:${senderId}:${timestamp}`;
  }
}
