/**
 * Detects Prisma's "unique constraint failed" error (P2002) without
 * importing Prisma.PrismaClientKnownRequestError as a class (avoids a
 * runtime import just for an instanceof check, and works the same whether
 * the thrown value came from the real client or a test double).
 *
 * Used everywhere a duplicate write should be treated as "someone already
 * did this" rather than a real failure — see customer.repository.ts
 * (racing PSID inserts) and webhookEvent.repository.ts (racing webhook
 * redelivery), the two places genuine concurrent duplicate writes are
 * expected in this codebase.
 */
export function isUniqueConstraintError(err: unknown): boolean {
  return typeof err === "object" && err !== null && (err as { code?: unknown }).code === "P2002";
}
