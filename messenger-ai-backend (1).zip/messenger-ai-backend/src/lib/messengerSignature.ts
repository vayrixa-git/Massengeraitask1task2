import crypto from "node:crypto";

/**
 * Verifies the `X-Hub-Signature-256` header Facebook sends on every webhook
 * POST: `sha256=<hex hmac of the raw request body, keyed by the App
 * Secret>`. Must run against the exact raw bytes Express received — hence
 * `rawBody` (see routes/messengerWebhook.routes.ts, which captures it via
 * express.json()'s `verify` option before JSON.parse ever runs).
 *
 * If no app secret is configured at all, verification is skipped (returns
 * true) rather than rejecting every request outright — this is a documented
 * local-dev-only fallback (see .env.example) for testing against a
 * webhook sender that doesn't sign requests. Every real deployment MUST set
 * MESSENGER_APP_SECRET; the route logs a warning every time this fallback
 * is used so it's impossible to miss in server logs.
 */
export function verifyMessengerSignature(
  rawBody: Buffer | undefined,
  signatureHeader: string | undefined,
  appSecret: string | undefined
): boolean {
  if (!appSecret) return true;
  if (!rawBody || !signatureHeader) return false;

  const [algo, signatureHex] = signatureHeader.split("=");
  if (algo !== "sha256" || !signatureHex) return false;

  const expectedHex = crypto.createHmac("sha256", appSecret).update(rawBody).digest("hex");

  const expected = Buffer.from(expectedHex, "utf8");
  const actual = Buffer.from(signatureHex, "utf8");
  if (expected.length !== actual.length) return false;

  return crypto.timingSafeEqual(expected, actual);
}
