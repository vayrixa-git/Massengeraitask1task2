import { Router, type Request, type Response, type NextFunction } from "express";
import express from "express";
import { getMessengerAppSecret, getMessengerVerifyToken } from "../config/messenger.config";
import { verifyMessengerSignature } from "../lib/messengerSignature";
import { messengerWebhookService } from "../services/messengerWebhook.service";
import { logger } from "../lib/logger";
import type { MessengerWebhookPayload } from "../types/messenger";
import type { ProcessEventResult } from "../services/messengerWebhook.service";

/** Augments Request with the raw body captured by express.json()'s `verify`
 * hook below — needed because signature verification must run over the
 * exact bytes received, before/regardless of JSON parsing. */
interface RequestWithRawBody extends Request {
  rawBody?: Buffer;
}

export const messengerWebhookRouter = Router();

// Body parsing lives on this router, not the whole app, so other future
// routes aren't forced through the same raw-body capture. `verify` stashes
// the raw bytes for the signature check in the POST handler below.
messengerWebhookRouter.use(
  express.json({
    verify: (req, _res, buf) => {
      (req as RequestWithRawBody).rawBody = Buffer.from(buf);
    },
  })
);

// Malformed JSON (requirement 15 "malformed request") is a body-parser error
// that would otherwise bubble to the app-level 500 handler — caught here so
// it gets the more accurate 400, without needing to know the parser's
// internals from a route consumer's perspective.
messengerWebhookRouter.use((err: unknown, _req: Request, res: Response, next: NextFunction) => {
  const isBodyParserError =
    err instanceof SyntaxError || (typeof err === "object" && err !== null && (err as { type?: unknown }).type === "entity.parse.failed");
  if (isBodyParserError) {
    logger.warn("webhook.malformed_payload", {});
    res.sendStatus(400);
    return;
  }
  next(err);
});

/**
 * GET /webhooks/messenger — the Messenger Platform's webhook verification
 * handshake, run once when the webhook URL is registered in the Meta App
 * dashboard. Must echo back hub.challenge verbatim on success.
 */
messengerWebhookRouter.get("/", (req: Request, res: Response) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  const expectedToken = getMessengerVerifyToken();

  if (mode === "subscribe" && !!expectedToken && token === expectedToken) {
    logger.info("webhook.verified", {});
    res.status(200).send(challenge);
    return;
  }

  logger.warn("webhook.verification_failed", {});
  res.sendStatus(403);
});

/**
 * POST /webhooks/messenger — the actual event delivery. Every response path
 * is deliberate about whether Facebook should retry (see
 * docs/TASK2_REPORT.md "Webhook response codes, and why"):
 *   401 invalid/missing signature — retrying won't produce a valid one
 *   404 not a Page subscription   — nothing here can ever process it
 *   200 known outcome (processed, duplicate, unknown page, unsupported
 *       event, missing sender)    — we handled it; nothing to gain by
 *                                   redelivery even when we chose not to
 *                                   act on it
 *   500 unexpected/internal error — invites Facebook's own retry, which is
 *                                   safe here because processing is
 *                                   idempotent (WebhookEvent + the unique
 *                                   externalMessageId constraint)
 */
messengerWebhookRouter.post("/", async (req: Request, res: Response) => {
  const signatureHeader = req.header("x-hub-signature-256");
  const rawBody = (req as RequestWithRawBody).rawBody;
  const appSecret = getMessengerAppSecret();

  if (!appSecret) {
    logger.warn("webhook.signature_verification_skipped", {
      reason: "MESSENGER_APP_SECRET not configured",
    });
  }

  if (!verifyMessengerSignature(rawBody, signatureHeader, appSecret)) {
    logger.warn("webhook.invalid_signature", {});
    res.sendStatus(401);
    return;
  }

  const body = req.body as MessengerWebhookPayload | undefined;
  if (!body || body.object !== "page") {
    res.sendStatus(404);
    return;
  }

  try {
    const results = await messengerWebhookService.processWebhookPayload(body);
    logger.info("webhook.batch_processed", { count: results.length, outcomes: summarizeOutcomes(results) });
    res.sendStatus(200);
  } catch (err) {
    logger.error("webhook.batch_failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    res.sendStatus(500);
  }
});

function summarizeOutcomes(results: ProcessEventResult[]): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const r of results) {
    counts[r.outcome] = (counts[r.outcome] ?? 0) + 1;
  }
  return counts;
}
