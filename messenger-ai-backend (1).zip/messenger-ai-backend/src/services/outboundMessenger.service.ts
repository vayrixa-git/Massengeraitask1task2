import { messageRepository } from "../repositories/message.repository";
import { messengerService, type IMessengerService } from "./messenger.service";
import { MissingAccessTokenError } from "../lib/errors";
import { logger } from "../lib/logger";
import type { Message } from "@prisma/client";

export type OutboundSendInput = {
  conversationId: string;
  customerId: string;
  recipientPsid: string;
  text: string;
  pageAccessToken: string | undefined;
  /** Who's actually sending — AI (default), a human agent taking over, or
   * a system-generated notice. Never CUSTOMER; that sender type is reserved
   * for inbound messages. */
  senderType?: "AI" | "HUMAN_AGENT" | "SYSTEM";
};

export type OutboundSendResult = {
  message: Message;
  providerMessageId: string;
};

/**
 * Requirement 13 ("outbound message recording"): AI/System → MessengerService
 * → Facebook, and AI/System → MessageService → Database, tied together in
 * one call so nothing that calls this can send a message and forget to
 * persist it (or vice versa). Deliberately does NOT create a Message row if
 * the send itself fails — nothing was actually delivered, so there is
 * nothing truthful to record; the error propagates so the caller (the
 * future AI Brain / Policy Layer) can decide whether to retry, log, or
 * surface an AIAction failure.
 */
export class OutboundMessengerService {
  constructor(private readonly messenger: IMessengerService = messengerService) {}

  async sendAndRecord(businessId: string, input: OutboundSendInput): Promise<OutboundSendResult> {
    if (!input.pageAccessToken) {
      throw new MissingAccessTokenError(businessId);
    }

    const sendResult = await this.messenger.sendTextMessage({
      recipientPsid: input.recipientPsid,
      pageAccessToken: input.pageAccessToken,
      text: input.text,
    });

    const message = await messageRepository.create(businessId, {
      conversationId: input.conversationId,
      customerId: input.customerId,
      senderType: input.senderType ?? "AI",
      content: input.text,
      externalMessageId: sendResult.providerMessageId,
      metadata: {
        platform: "messenger",
        direction: "outbound",
        providerMessageId: sendResult.providerMessageId,
      },
    });

    logger.info("messenger.outbound_recorded", {
      businessId,
      conversationId: input.conversationId,
      messageId: message.id,
    });

    return { message, providerMessageId: sendResult.providerMessageId };
  }
}

export const outboundMessengerService = new OutboundMessengerService();
