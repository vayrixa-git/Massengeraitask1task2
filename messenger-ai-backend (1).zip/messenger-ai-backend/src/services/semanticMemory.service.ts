import { memoryRepository } from "../repositories/memory.repository";

export type SemanticMatch = {
  id: string;
  content: string;
  memoryType: string;
  importance: number;
  distance: number; // cosine distance, lower = more similar
};

/**
 * The exact integration point for semantic memory search.
 *
 * pgvector IS enabled on this database (see prisma/migrations/.../migration.sql
 * — `CREATE EXTENSION vector` plus `CustomerMemory.embedding vector(1536)`),
 * so this ships a real, working implementation, not a stub. It's still kept
 * behind this interface because:
 *   1. Nothing populates `embedding` yet — that requires an embedding model
 *      call, which is explicitly out of scope for this task ("do not build
 *      the AI agent"). Every memory currently has embedding = NULL.
 *   2. When that later task picks an embedding provider/dimension, only
 *      `PgVectorSemanticMemoryService` (and the `vector(1536)` width, if the
 *      chosen model differs) needs to change — MemoryService and everything
 *      above it never touches raw SQL or vector math directly.
 */
export interface SemanticMemoryService {
  upsertEmbedding(businessId: string, memoryId: string, embedding: number[]): Promise<boolean>;
  findSimilar(
    businessId: string,
    customerId: string,
    queryEmbedding: number[],
    limit?: number
  ): Promise<SemanticMatch[]>;
}

export class PgVectorSemanticMemoryService implements SemanticMemoryService {
  async upsertEmbedding(businessId: string, memoryId: string, embedding: number[]) {
    return memoryRepository.setEmbedding(businessId, memoryId, embedding);
  }

  async findSimilar(
    businessId: string,
    customerId: string,
    queryEmbedding: number[],
    limit = 5
  ) {
    return memoryRepository.findSimilar(businessId, customerId, queryEmbedding, limit);
  }
}

/** No-op fallback for a deployment where pgvector can't be enabled — lets
 * MemoryService degrade to its importance/recency ranking instead of
 * throwing. Not used by default here since pgvector is available. */
export class NullSemanticMemoryService implements SemanticMemoryService {
  async upsertEmbedding(): Promise<boolean> {
    return false;
  }
  async findSimilar(): Promise<SemanticMatch[]> {
    return [];
  }
}
