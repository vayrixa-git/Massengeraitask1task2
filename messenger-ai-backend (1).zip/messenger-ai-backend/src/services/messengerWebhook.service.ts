import { businessResolverService, type IBusinessResolverService } from "./businessResolver.service";
import { customerRepository } from "../repositories/customer.repository";
import { conversationRepository } from "../repositories/conversation.repository";
import { webhookEventRepository } from "../repositories/webhookEvent.repository";
import { getAIPipelineHook } from "./aiPipeline.hook";
import { classifyMessagingEvent, buildDedupeKey } from "../lib/messengerEvent";
import { logger } from "../lib/logger";
import type {
  MessengerMessagingEvent,
  MessengerWebhookEntry,
  MessengerWebhookPayload,
} from "../types/messenger";
import type { IncomingMessengerMessage } from "../types";

/**
 * The outcome of processing exactly one Messenger "messaging" event —
 * returned so the route handler can log a compact summary of a whole batch
 * without re-deriving what happened. Never contains message content or PII;
 * only ids and a category.
 */
export type ProcessEventResult =
  | { outcome: "processed"; businessId: string; conversationId: string; messageId: string }
  | { outcome: "duplicate"; businessId: string; dedupeKey: string }
  | { outcome: "unknown_page"; pageId: string }
  | { outcome: "unsupported_event"; businessId: string; eventType: string }
  | { outcome: "ignored"; reason: string };

export interface IMessengerWebhookService {
  processWebhookPayload(payload: MessengerWebhookPayload): Promise<ProcessEventResult[]>;
}

/**
 * Requirement 11's pipeline, made concrete:
 *   MessengerWebhookController (routes/messengerWebhook.routes.ts)
 *     → MessengerWebhookService (this file)
 *       → BusinessResolverService
 *       → customerRepository / conversationRepository (play the
 *         "CustomerService" / "ConversationService" role — see
 *         docs/TASK2_REPORT.md "Architecture decisions" for why no
 *         additional pass-through service wraps them)
 *       → webhookEventRepository (idempotent Message + ledger write)
 *       → AIPipelineHook (Task 3's seam)
 */
export class MessengerWebhookService implements IMessengerWebhookService {
  constructor(private readonly businessResolver: IBusinessResolverService = businessResolverService) {}

  async processWebhookPayload(payload: MessengerWebhookPayload): Promise<ProcessEventResult[]> {
    const results: ProcessEventResult[] = [];

    for (const entry of payload.entry ?? []) {
      for (const event of entry.messaging ?? []) {
        results.push(await this.processSingleEvent(entry, event));
      }
    }

    return results;
  }

  private async processSingleEvent(
    entry: MessengerWebhookEntry,
    event: MessengerMessagingEvent
  ): Promise<ProcessEventResult> {
    const pageId = entry.id;

    const business = await this.businessResolver.resolveByMessengerPageId(pageId);
    if (!business) {
      // Requirement 2: never create a business for an unknown page; log
      // enough to debug (the page id) without exposing anything secret,
      // and let the caller respond 200 — retrying won't fix an unmapped
      // page, that needs an admin action (connecting the Page).
      logger.warn("webhook.unknown_page", { pageId });
      return { outcome: "unknown_page", pageId };
    }
    const businessId = business.id;

    const eventType = classifyMessagingEvent(event);
    const dedupeKey = buildDedupeKey(event, eventType);

    // Fast path: skip all further work if we've unambiguously seen this
    // exact event before. This is an optimization only — the transactional
    // unique-constraint writes below are what actually guarantee no
    // duplicate Customer/Conversation/Message under real concurrency (see
    // webhookEvent.repository.ts file header).
    const alreadySeen = await webhookEventRepository.findByDedupeKey(businessId, dedupeKey);
    if (alreadySeen) {
      logger.info("webhook.duplicate_event", { businessId, dedupeKey, eventType });
      return { outcome: "duplicate", businessId, dedupeKey };
    }

    if (eventType !== "message") {
      const recorded = await webhookEventRepository.tryRecordEvent(businessId, dedupeKey, eventType);
      if (!recorded) {
        logger.info("webhook.duplicate_event", { businessId, dedupeKey, eventType });
        return { outcome: "duplicate", businessId, dedupeKey };
      }
      logger.info("webhook.unsupported_event", { businessId, eventType });
      return { outcome: "unsupported_event", businessId, eventType };
    }

    const senderPsid = event.sender?.id;
    if (!senderPsid) {
      logger.warn("webhook.missing_sender", { businessId, eventType });
      return { outcome: "ignored", reason: "missing_sender" };
    }

    const customer = await customerRepository.findOrCreateByMessengerPsid(businessId, senderPsid);
    logger.info("webhook.customer_resolved", { businessId, customerId: customer.id });

    const conversation = await conversationRepository.findOrCreateActiveForCustomer(businessId, customer.id);
    logger.info("webhook.conversation_resolved", { businessId, conversationId: conversation.id });

    // Text is the only content type Task 2 actually understands (requirement
    // 7). Attachments/quick replies are preserved in metadata untouched, so
    // a later task can add real handling for them without a schema change —
    // but the stored `content` is a safe, non-crashing placeholder for now.
    const content = event.message?.text ?? "[unsupported message content]";

    const { message, created } = await webhookEventRepository.recordIncomingMessage(businessId, {
      dedupeKey,
      conversationId: conversation.id,
      customerId: customer.id,
      content,
      externalMessageId: event.message?.mid,
      metadata: {
        platform: "messenger",
        mid: event.message?.mid,
        attachments: event.message?.attachments ?? undefined,
        quickReplyPayload: event.message?.quick_reply?.payload,
        timestamp: event.timestamp,
      },
    });

    if (!created) {
      logger.info("webhook.duplicate_event", { businessId, dedupeKey, eventType });
      return { outcome: "duplicate", businessId, dedupeKey };
    }

    logger.info("webhook.message_stored", { businessId, conversationId: conversation.id, messageId: message.id });

    const incomingMessage: IncomingMessengerMessage = {
      businessId,
      customerId: customer.id,
      conversationId: conversation.id,
      messageId: message.id,
      messengerPsid: senderPsid,
      text: content,
      timestamp: message.createdAt,
      metadata: { mid: event.message?.mid },
    };

    // Never let a future AI pipeline's own failure break webhook ingestion —
    // the message is already durably stored at this point regardless.
    try {
      await getAIPipelineHook().onIncomingMessage(incomingMessage);
    } catch (err) {
      logger.error("webhook.ai_pipeline_hook_failed", {
        businessId,
        messageId: message.id,
        error: err instanceof Error ? err.message : String(err),
      });
    }

    return { outcome: "processed", businessId, conversationId: conversation.id, messageId: message.id };
  }
}

export const messengerWebhookService = new MessengerWebhookService();
