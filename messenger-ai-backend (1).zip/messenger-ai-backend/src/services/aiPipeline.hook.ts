import type { IncomingMessengerMessage } from "../types";
import { logger } from "../lib/logger";

/**
 * The exact seam requirement 12 asks for: "Message → Context Builder →
 * Memory Retrieval → AI Brain, without rewriting the Messenger webhook."
 * MessengerWebhookService calls `aiPipelineHook.onIncomingMessage(...)` once
 * — and only once — a new inbound message has been durably stored (never
 * for a duplicate/replayed webhook event). Task 3 replaces the no-op default
 * below with real logic by calling setAIPipelineHook(); nothing in the
 * webhook/service layer above this needs to change when that happens.
 *
 * Deliberately does NOT call an LLM, build context, or retrieve memory —
 * that's explicitly out of scope for Task 2 (requirement 20).
 */
export interface AIPipelineHook {
  onIncomingMessage(message: IncomingMessengerMessage): Promise<void>;
}

export class NoopAIPipelineHook implements AIPipelineHook {
  async onIncomingMessage(message: IncomingMessengerMessage): Promise<void> {
    logger.info("ai_pipeline.noop", {
      businessId: message.businessId,
      conversationId: message.conversationId,
      messageId: message.messageId,
    });
  }
}

let currentHook: AIPipelineHook = new NoopAIPipelineHook();

export function getAIPipelineHook(): AIPipelineHook {
  return currentHook;
}

/** Lets Task 3 (or a test) install a real implementation without touching
 * MessengerWebhookService. */
export function setAIPipelineHook(hook: AIPipelineHook): void {
  currentHook = hook;
}
