import { businessRepository } from "../repositories/business.repository";
import { getFallbackMessengerAccessToken } from "../config/messenger.config";

export type ResolvedBusiness = {
  id: string;
  name: string;
  /** The token to use for outbound sends to this business's Page — the
   * business's own token if it has one, else the shared local-dev fallback
   * from MESSENGER_ACCESS_TOKEN. See .env.example. */
  pageAccessToken: string | undefined;
};

export interface IBusinessResolverService {
  resolveByMessengerPageId(pageId: string): Promise<ResolvedBusiness | null>;
}

/**
 * The "Messenger Page ID → Business" step (requirement 2). Deliberately
 * does nothing on a miss — no record is created for an unrecognized page;
 * the caller (MessengerWebhookService) logs and returns 200 without further
 * processing, exactly as requirement 2 specifies.
 */
export class BusinessResolverService implements IBusinessResolverService {
  async resolveByMessengerPageId(pageId: string): Promise<ResolvedBusiness | null> {
    const business = await businessRepository.findByMessengerPageId(pageId);
    if (!business) return null;

    return {
      id: business.id,
      name: business.name,
      pageAccessToken: business.messengerPageAccessToken ?? getFallbackMessengerAccessToken(),
    };
  }
}

export const businessResolverService = new BusinessResolverService();
