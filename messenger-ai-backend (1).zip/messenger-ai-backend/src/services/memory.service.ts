import { memoryRepository } from "../repositories/memory.repository";
import { customerRepository } from "../repositories/customer.repository";
import { conversationRepository } from "../repositories/conversation.repository";
import { prisma } from "../db/client";
import type { SaveMemoryInput, CustomerContext } from "../types";
import {
  PgVectorSemanticMemoryService,
  type SemanticMemoryService,
} from "./semanticMemory.service";

/**
 * MemoryService is the only thing the rest of the app (and, later, the AI
 * agent) should call to read or write customer memory — nobody should import
 * memoryRepository directly outside this file. That keeps the
 * update/invalidate/expire lifecycle rules in one place instead of scattered
 * across call sites.
 */
export interface IMemoryService {
  saveMemory(businessId: string, input: SaveMemoryInput): Promise<{ id: string }>;
  updateMemory(
    businessId: string,
    memoryId: string,
    newContent: SaveMemoryInput
  ): Promise<{ id: string }>;
  invalidateMemory(businessId: string, memoryId: string): Promise<boolean>;
  getRelevantMemories(
    businessId: string,
    customerId: string,
    opts?: { queryEmbedding?: number[]; limit?: number }
  ): Promise<Array<{ id: string; content: string; memoryType: string; importance: number }>>;
  getCustomerMemory(
    businessId: string,
    customerId: string
  ): Promise<Array<{ id: string; content: string; memoryType: string; importance: number; status: string }>>;
  buildCustomerContext(businessId: string, customerId: string): Promise<CustomerContext | null>;
}

export class MemoryService implements IMemoryService {
  constructor(private readonly semantic: SemanticMemoryService = new PgVectorSemanticMemoryService()) {}

  async saveMemory(businessId: string, input: SaveMemoryInput) {
    const memory = await memoryRepository.create(businessId, input);
    if (input.embedding) {
      await this.semantic.upsertEmbedding(businessId, memory.id, input.embedding);
    }
    return { id: memory.id };
  }

  /** Never mutates an ACTIVE memory's content in place — it supersedes it,
   * so the old value stays in the audit trail instead of being lost. */
  async updateMemory(businessId: string, memoryId: string, newContent: SaveMemoryInput) {
    const replacement = await memoryRepository.supersede(businessId, memoryId, newContent);
    if (newContent.embedding) {
      await this.semantic.upsertEmbedding(businessId, replacement.id, newContent.embedding);
    }
    return { id: replacement.id };
  }

  async invalidateMemory(businessId: string, memoryId: string) {
    return memoryRepository.invalidate(businessId, memoryId);
  }

  /** Semantic search when a query embedding is supplied and returns matches;
   * otherwise (or if nothing has an embedding yet) falls back to importance +
   * recency ranking. This fallback is why the rest of the app works
   * correctly today even though nothing populates embeddings yet. */
  async getRelevantMemories(
    businessId: string,
    customerId: string,
    opts: { queryEmbedding?: number[]; limit?: number } = {}
  ) {
    const limit = opts.limit ?? 5;

    if (opts.queryEmbedding) {
      const matches = await this.semantic.findSimilar(businessId, customerId, opts.queryEmbedding, limit);
      if (matches.length > 0) {
        return matches.map((m) => ({
          id: m.id,
          content: m.content,
          memoryType: m.memoryType,
          importance: m.importance,
        }));
      }
    }

    const active = await memoryRepository.findActiveForCustomer(businessId, customerId, { limit });
    return active.map((m) => ({
      id: m.id,
      content: m.content,
      memoryType: m.memoryType,
      importance: m.importance,
    }));
  }

  async getCustomerMemory(businessId: string, customerId: string) {
    const rows = await prisma.customerMemory.findMany({
      where: { businessId, customerId },
      orderBy: [{ status: "asc" }, { updatedAt: "desc" }],
    });
    return rows.map((m) => ({
      id: m.id,
      content: m.content,
      memoryType: m.memoryType,
      importance: m.importance,
      status: m.status,
    }));
  }

  /** The single call an AI context-builder makes before replying: who this
   * customer is, what's worth remembering about them, and what their recent
   * conversations were about. */
  async buildCustomerContext(businessId: string, customerId: string): Promise<CustomerContext | null> {
    const customer = await customerRepository.findById(businessId, customerId);
    if (!customer) return null;

    const activeMemories = await this.getRelevantMemories(businessId, customerId, { limit: 10 });

    const recentConversations = await conversationRepository.listForCustomer(businessId, customerId, {
      take: 3,
    });

    return {
      customer: {
        id: customer.id,
        name: customer.name,
        phone: customer.phone,
        email: customer.email,
      },
      activeMemories,
      recentConversationSummaries: recentConversations
        .map((c) => c.summary)
        .filter((s): s is string => !!s),
    };
  }
}

export const memoryService = new MemoryService();
