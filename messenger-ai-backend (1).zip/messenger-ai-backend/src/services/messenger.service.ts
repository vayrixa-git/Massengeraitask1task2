import { logger } from "../lib/logger";
import { MessengerApiError, MissingAccessTokenError } from "../lib/errors";

const GRAPH_API_BASE = "https://graph.facebook.com";
// Pin a specific stable Graph API version rather than floating on the
// default — bump deliberately (and re-test) when Meta deprecates this one.
const GRAPH_API_VERSION = "v21.0";

export type SendMessagePayload = Record<string, unknown>;

export type MessengerSendResult = {
  recipientId: string;
  /** Graph API's own message id for the sent message — stored as this
   * codebase's Message.externalMessageId for the outbound row. */
  providerMessageId: string;
};

export interface IMessengerService {
  sendMessage(input: {
    recipientPsid: string;
    pageAccessToken: string | undefined;
    message: SendMessagePayload;
  }): Promise<MessengerSendResult>;
  sendTextMessage(input: {
    recipientPsid: string;
    pageAccessToken: string | undefined;
    text: string;
  }): Promise<MessengerSendResult>;
}

/**
 * The ONLY place Facebook Graph API calls happen (requirement 8 — "Do NOT
 * scatter Facebook API calls throughout controllers/services"). Everything
 * above this (OutboundMessengerService, and eventually the AI Brain) talks
 * to this interface, never to `fetch` or the Graph API directly.
 *
 * `fetchImpl` is injectable so tests can supply a fake fetch and never make
 * a real network call (requirement 15 — "Do NOT make real Facebook API
 * calls during automated tests"), without adding a mocking-library
 * dependency. Node 22's global `fetch` is used by default.
 */
export class MessengerService implements IMessengerService {
  constructor(private readonly fetchImpl: typeof fetch = fetch) {}

  async sendMessage(input: {
    recipientPsid: string;
    pageAccessToken: string | undefined;
    message: SendMessagePayload;
  }): Promise<MessengerSendResult> {
    if (!input.pageAccessToken) {
      // Caller's businessId isn't known at this layer by design (this
      // service only knows about Messenger, not the tenant model) — the
      // caller (OutboundMessengerService) is responsible for raising this
      // with businessId attached; this bare check exists so a missing token
      // NEVER silently becomes an unauthenticated Graph API call.
      throw new MissingAccessTokenError("unknown");
    }

    const url = `${GRAPH_API_BASE}/${GRAPH_API_VERSION}/me/messages?access_token=${encodeURIComponent(
      input.pageAccessToken
    )}`;

    const response = await this.fetchImpl(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_type: "RESPONSE",
        recipient: { id: input.recipientPsid },
        message: input.message,
      }),
    });

    if (!response.ok) {
      // Log status only — never the response body (Graph API error bodies
      // can echo back request fields) and never the access token, which
      // only ever appears in the URL we just built, not in anything logged.
      logger.error("messenger.send_failed", { status: response.status });
      throw new MessengerApiError(response.status);
    }

    const data = (await response.json()) as { recipient_id: string; message_id: string };
    return { recipientId: data.recipient_id, providerMessageId: data.message_id };
  }

  async sendTextMessage(input: {
    recipientPsid: string;
    pageAccessToken: string | undefined;
    text: string;
  }): Promise<MessengerSendResult> {
    return this.sendMessage({
      recipientPsid: input.recipientPsid,
      pageAccessToken: input.pageAccessToken,
      message: { text: input.text },
    });
  }
}

export const messengerService = new MessengerService();
