import { createApp } from "./app";
import { getServerPort } from "./config/messenger.config";
import { logger } from "./lib/logger";
import { disconnectDb } from "./db/client";

const app = createApp();
const port = getServerPort();

const server = app.listen(port, () => {
  logger.info("server.started", { port });
});

async function shutdown(signal: string): Promise<void> {
  logger.info("server.shutting_down", { signal });
  server.close(async () => {
    await disconnectDb();
    process.exit(0);
  });
}

process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));
