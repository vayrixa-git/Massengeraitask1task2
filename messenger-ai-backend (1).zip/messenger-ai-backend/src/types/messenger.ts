/**
 * Typed subset of Facebook's Messenger Platform webhook payload — just the
 * fields this codebase actually reads. Not an exhaustive mirror of Meta's
 * schema (attachments/postback/delivery/read payloads carry more fields than
 * are modeled here); extend as future message-type support is added.
 *
 * Reference shape (POST body of a Page-subscribed webhook):
 * {
 *   "object": "page",
 *   "entry": [{
 *     "id": "<PAGE_ID>",
 *     "time": 1458692752478,
 *     "messaging": [{
 *       "sender": { "id": "<PSID>" },
 *       "recipient": { "id": "<PAGE_ID>" },
 *       "timestamp": 1458692752478,
 *       "message": { "mid": "...", "text": "..." }
 *       // — or "postback" / "delivery" / "read" instead of "message"
 *     }]
 *   }]
 * }
 */

export interface MessengerAttachment {
  type: string;
  payload?: Record<string, unknown>;
}

export interface MessengerQuickReply {
  payload: string;
}

export interface MessengerMessage {
  mid: string;
  text?: string;
  quick_reply?: MessengerQuickReply;
  attachments?: MessengerAttachment[];
  is_echo?: boolean;
}

export interface MessengerPostback {
  title?: string;
  payload: string;
}

export interface MessengerDelivery {
  mids?: string[];
  watermark: number;
}

export interface MessengerRead {
  watermark: number;
}

export interface MessengerMessagingEvent {
  sender?: { id: string };
  recipient?: { id: string };
  timestamp?: number;
  message?: MessengerMessage;
  postback?: MessengerPostback;
  delivery?: MessengerDelivery;
  read?: MessengerRead;
}

export interface MessengerWebhookEntry {
  /** The Facebook Page ID this batch of events was delivered for. */
  id: string;
  time?: number;
  messaging?: MessengerMessagingEvent[];
}

export interface MessengerWebhookPayload {
  object: string;
  entry?: MessengerWebhookEntry[];
}

export type MessengerEventType = "message" | "postback" | "delivery" | "read" | "unsupported";
