/**
 * Every repository/service method that touches business-owned data takes an
 * explicit businessId as its first argument (never inferred, never optional).
 * This is the single load-bearing convention that enforces tenant isolation —
 * see docs/ARCHITECTURE.md "Tenant isolation" for why it's done this way
 * instead of e.g. row-level security or a global request-scoped context.
 */
export type TenantScope = {
  businessId: string;
};

export type CreateCustomerInput = {
  messengerPsid?: string | null;
  name?: string | null;
  phone?: string | null;
  email?: string | null;
};

export type CreateMessageInput = {
  conversationId: string;
  customerId?: string | null;
  senderType: "CUSTOMER" | "AI" | "HUMAN_AGENT" | "SYSTEM";
  content: string;
  /** Messenger "mid" (inbound) or Graph API message id (outbound) — see
   * Message.externalMessageId. Optional/omittable for non-Messenger rows. */
  externalMessageId?: string | null;
  metadata?: Record<string, unknown>;
};

/**
 * Task 2's contract with Task 3 (the AI Brain) — see
 * docs/TASK2_REPORT.md "Future AI pipeline contract". A valid inbound
 * Messenger message has been durably stored (Message + Conversation +
 * Customer all committed) by the time this is built; Task 3 receives it via
 * AIPipelineHook.onIncomingMessage (src/services/aiPipeline.hook.ts) and
 * builds context/memory/response from it without touching the webhook code
 * above it.
 */
export type IncomingMessengerMessage = {
  businessId: string;
  customerId: string;
  conversationId: string;
  messageId: string;
  messengerPsid: string;
  text: string;
  timestamp: Date;
  metadata: Record<string, unknown>;
};

export type SaveMemoryInput = {
  customerId: string;
  content: string;
  memoryType?:
    | "PREFERENCE"
    | "FACT"
    | "LIFE_EVENT"
    | "COMPLAINT"
    | "PURCHASE_INTENT"
    | "CONTACT_INFO"
    | "OTHER";
  importance?: number; // 1..5
  confidence?: number; // 0..1
  source?:
    | "EXPLICIT_STATEMENT"
    | "INFERRED"
    | "CONVERSATION_SUMMARY"
    | "MANUAL_ENTRY"
    | "ORDER_HISTORY";
  expiresAt?: Date | null;
  embedding?: number[] | null;
};

export type CustomerContext = {
  customer: {
    id: string;
    name: string | null;
    phone: string | null;
    email: string | null;
  };
  activeMemories: Array<{
    id: string;
    content: string;
    memoryType: string;
    importance: number;
    confidence: number;
  }>;
  recentConversationSummaries: string[];
};
