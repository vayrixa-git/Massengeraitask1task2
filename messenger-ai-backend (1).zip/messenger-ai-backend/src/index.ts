import { prisma, disconnectDb } from "./db/client";

/**
 * Minimal boot check: connect, confirm the schema is reachable, confirm
 * pgvector is enabled, then exit cleanly. This is what "the application
 * still starts" means for a data-layer-only task with no HTTP server yet —
 * a real server (Messenger webhook handler, etc.) is a later task and would
 * import prisma/repositories/services exactly as this file does.
 */
async function main() {
  await prisma.$connect();
  const businessCount = await prisma.business.count();
  const [{ extname }] = await prisma.$queryRaw<Array<{ extname: string }>>`
    SELECT extname FROM pg_extension WHERE extname = 'vector'
  `;

  console.log("Messenger AI backend — boot check");
  console.log(`  Database connected: yes`);
  console.log(`  pgvector extension: ${extname ? "enabled" : "MISSING"}`);
  console.log(`  Business rows: ${businessCount}`);
}

main()
  .then(async () => {
    await disconnectDb();
    process.exit(0);
  })
  .catch(async (err) => {
    console.error("Boot check failed:", err);
    await disconnectDb();
    process.exit(1);
  });
