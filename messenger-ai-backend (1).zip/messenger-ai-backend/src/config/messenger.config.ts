/**
 * All Messenger-related env vars, read lazily (at call time, not module load
 * time) so tests can set process.env per-test without import-order games.
 * See .env.example for what each one is and how to obtain it.
 */

/** The string configured in the Meta App's webhook subscription — GET /webhooks/messenger checks hub.verify_token against this. */
export function getMessengerVerifyToken(): string | undefined {
  return process.env.MESSENGER_VERIFY_TOKEN;
}

/** The Meta App Secret — used to verify X-Hub-Signature-256 on every POST. Shared across all Pages subscribed to this app. */
export function getMessengerAppSecret(): string | undefined {
  return process.env.MESSENGER_APP_SECRET;
}

/**
 * Fallback Page Access Token, used only when a Business row has no
 * messengerPageAccessToken of its own. Convenient for local dev with a
 * single test Page; every real tenant should have its own token on the
 * Business row instead (see businessResolver.service.ts).
 */
export function getFallbackMessengerAccessToken(): string | undefined {
  return process.env.MESSENGER_ACCESS_TOKEN;
}

export function getServerPort(): number {
  const raw = process.env.PORT;
  const parsed = raw ? Number(raw) : NaN;
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 3000;
}
