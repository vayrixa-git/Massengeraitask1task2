import { PrismaClient } from "@prisma/client";

// Single shared PrismaClient instance (Prisma's recommended pattern — avoids
// exhausting the Postgres connection pool with one client per request in
// dev/hot-reload environments).
declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma =
  global.__prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  global.__prisma = prisma;
}

export async function disconnectDb(): Promise<void> {
  await prisma.$disconnect();
}
