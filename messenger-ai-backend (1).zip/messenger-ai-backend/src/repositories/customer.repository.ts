import { prisma } from "../db/client";
import type { CreateCustomerInput } from "../types";
import { isUniqueConstraintError } from "../lib/prismaErrors";

/**
 * Every method requires businessId and every query is filtered by it.
 * This is the pattern all repositories in this project follow — see
 * docs/ARCHITECTURE.md "Tenant isolation".
 */
export const customerRepository = {
  async create(businessId: string, input: CreateCustomerInput) {
    return prisma.customer.create({
      data: { businessId, ...input },
    });
  },

  async findById(businessId: string, customerId: string) {
    return prisma.customer.findFirst({
      where: { id: customerId, businessId },
    });
  },

  async findByMessengerPsid(businessId: string, messengerPsid: string) {
    return prisma.customer.findFirst({
      where: { businessId, messengerPsid },
    });
  },

  /** Get-or-create by Messenger PSID — the common entry point for inbound
   * webhooks. Safe under concurrent duplicate delivery: two requests racing
   * to create the same brand-new customer can't both succeed (the schema's
   * `@@unique([businessId, messengerPsid])` constraint guarantees that), and
   * the loser here re-fetches instead of throwing, so callers never see the
   * race — they just get the one row that won. */
  async findOrCreateByMessengerPsid(
    businessId: string,
    messengerPsid: string,
    fallback?: Partial<CreateCustomerInput>
  ) {
    const existing = await prisma.customer.findFirst({
      where: { businessId, messengerPsid },
    });
    if (existing) return existing;

    try {
      return await prisma.customer.create({
        data: { businessId, messengerPsid, ...fallback },
      });
    } catch (err) {
      if (isUniqueConstraintError(err)) {
        const raced = await prisma.customer.findFirst({
          where: { businessId, messengerPsid },
        });
        if (raced) return raced;
      }
      throw err;
    }
  },

  async update(
    businessId: string,
    customerId: string,
    data: Partial<CreateCustomerInput>
  ) {
    const { count } = await prisma.customer.updateMany({
      where: { id: customerId, businessId },
      data,
    });
    if (count === 0) return null;
    return prisma.customer.findFirst({ where: { id: customerId, businessId } });
  },

  async list(businessId: string, opts: { skip?: number; take?: number } = {}) {
    return prisma.customer.findMany({
      where: { businessId },
      orderBy: { createdAt: "desc" },
      skip: opts.skip,
      take: opts.take ?? 50,
    });
  },
};
