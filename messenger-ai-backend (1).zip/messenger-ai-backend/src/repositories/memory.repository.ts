import { Prisma } from "@prisma/client";
import { prisma } from "../db/client";
import type { SaveMemoryInput } from "../types";

/**
 * CustomerMemory has an `embedding vector(1536)` column that Prisma models as
 * `Unsupported("vector(1536)")` — it exists in the generated client's SQL
 * layer but is invisible to the normal `create`/`update`/`select` API, so
 * every read or write that touches it goes through $queryRaw/$executeRaw
 * here. Everything else uses the normal Prisma Client API. This is the one
 * and only place raw SQL is allowed to leak into the data-access layer — see
 * docs/ARCHITECTURE.md "Semantic memory" for the reasoning.
 */
export const memoryRepository = {
  async create(businessId: string, input: SaveMemoryInput) {
    return prisma.customerMemory.create({
      data: {
        businessId,
        customerId: input.customerId,
        content: input.content,
        memoryType: input.memoryType ?? "OTHER",
        importance: input.importance ?? 3,
        confidence: input.confidence ?? 0.8,
        source: input.source ?? "EXPLICIT_STATEMENT",
        expiresAt: input.expiresAt ?? null,
      },
    });
  },

  async findById(businessId: string, memoryId: string) {
    return prisma.customerMemory.findFirst({
      where: { id: memoryId, businessId },
    });
  },

  async findActiveForCustomer(
    businessId: string,
    customerId: string,
    opts: { memoryType?: string; limit?: number } = {}
  ) {
    return prisma.customerMemory.findMany({
      where: {
        businessId,
        customerId,
        status: "ACTIVE",
        ...(opts.memoryType ? { memoryType: opts.memoryType as any } : {}),
        OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
      },
      orderBy: [{ importance: "desc" }, { updatedAt: "desc" }],
      take: opts.limit ?? 50,
    });
  },

  /** Plain content/metadata edit — does not change status or version chain. */
  async update(
    businessId: string,
    memoryId: string,
    data: Partial<Pick<SaveMemoryInput, "content" | "importance" | "confidence" | "expiresAt">>
  ) {
    const { count } = await prisma.customerMemory.updateMany({
      where: { id: memoryId, businessId },
      data,
    });
    if (count === 0) return null;
    return prisma.customerMemory.findFirst({ where: { id: memoryId, businessId } });
  },

  /** Replaces an ACTIVE memory with a new row and marks the old one SUPERSEDED,
   * instead of overwriting it — so memory history stays auditable. */
  async supersede(businessId: string, oldMemoryId: string, newInput: SaveMemoryInput) {
    return prisma.$transaction(async (tx) => {
      const old = await tx.customerMemory.findFirst({
        where: { id: oldMemoryId, businessId },
      });
      if (!old) throw new Error(`Memory ${oldMemoryId} not found for business ${businessId}`);

      const replacement = await tx.customerMemory.create({
        data: {
          businessId,
          customerId: old.customerId,
          content: newInput.content,
          memoryType: newInput.memoryType ?? old.memoryType,
          importance: newInput.importance ?? old.importance,
          confidence: newInput.confidence ?? old.confidence,
          source: newInput.source ?? old.source,
          expiresAt: newInput.expiresAt ?? old.expiresAt,
          supersedesId: old.id,
        },
      });

      await tx.customerMemory.update({
        where: { id: old.id },
        data: { status: "SUPERSEDED" },
      });

      return replacement;
    });
  },

  async invalidate(businessId: string, memoryId: string) {
    const { count } = await prisma.customerMemory.updateMany({
      where: { id: memoryId, businessId },
      data: { status: "INVALIDATED" },
    });
    return count > 0;
  },

  /** Marks any ACTIVE memory past its expiresAt as EXPIRED. Call periodically
   * (cron/job queue) rather than on every read. */
  async expireDueMemories(businessId: string) {
    const { count } = await prisma.customerMemory.updateMany({
      where: { businessId, status: "ACTIVE", expiresAt: { lt: new Date() } },
      data: { status: "EXPIRED" },
    });
    return count;
  },

  // -- Vector operations (raw SQL — see file header) --------------------

  async setEmbedding(businessId: string, memoryId: string, embedding: number[]) {
    const vectorLiteral = toVectorLiteral(embedding);
    const result = await prisma.$executeRaw`
      UPDATE "CustomerMemory"
      SET "embedding" = ${vectorLiteral}::vector
      WHERE "id" = ${memoryId} AND "businessId" = ${businessId}
    `;
    return result > 0;
  },

  /** Cosine-similarity nearest neighbors among this customer's ACTIVE
   * memories. Requires embeddings to have been populated via setEmbedding —
   * rows with no embedding are excluded, not treated as distance 0. */
  async findSimilar(
    businessId: string,
    customerId: string,
    queryEmbedding: number[],
    limit = 5
  ): Promise<Array<{ id: string; content: string; memoryType: string; importance: number; distance: number }>> {
    const vectorLiteral = toVectorLiteral(queryEmbedding);
    return prisma.$queryRaw`
      SELECT "id", "content", "memoryType", "importance",
             ("embedding" <=> ${vectorLiteral}::vector) AS distance
      FROM "CustomerMemory"
      WHERE "businessId" = ${businessId}
        AND "customerId" = ${customerId}
        AND "status" = 'ACTIVE'
        AND "embedding" IS NOT NULL
      ORDER BY distance ASC
      LIMIT ${limit}
    `;
  },
};

function toVectorLiteral(values: number[]): string {
  if (!Array.isArray(values) || values.length === 0) {
    throw new Error("embedding must be a non-empty number array");
  }
  return `[${values.join(",")}]`;
}

export type { Prisma };
