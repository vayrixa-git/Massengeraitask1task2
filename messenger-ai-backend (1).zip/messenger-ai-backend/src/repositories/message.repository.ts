import { prisma } from "../db/client";
import type { CreateMessageInput } from "../types";
import { conversationRepository } from "./conversation.repository";

export const messageRepository = {
  /** Creates the message and bumps the parent conversation's lastMessageAt
   * in one transaction, so the two never drift apart. */
  async create(businessId: string, input: CreateMessageInput) {
    return prisma.$transaction(async (tx) => {
      const conversation = await tx.conversation.findFirst({
        where: { id: input.conversationId, businessId },
      });
      if (!conversation) {
        throw new Error(
          `Conversation ${input.conversationId} not found for business ${businessId}`
        );
      }

      const message = await tx.message.create({
        data: {
          businessId,
          conversationId: input.conversationId,
          customerId: input.customerId ?? null,
          senderType: input.senderType,
          content: input.content,
          externalMessageId: input.externalMessageId ?? null,
          metadata: (input.metadata ?? {}) as any,
        },
      });

      await tx.conversation.update({
        where: { id: input.conversationId },
        data: { lastMessageAt: message.createdAt },
      });

      return message;
    });
  },

  async listForConversation(
    businessId: string,
    conversationId: string,
    opts: { skip?: number; take?: number } = {}
  ) {
    return prisma.message.findMany({
      where: { businessId, conversationId },
      orderBy: { createdAt: "asc" },
      skip: opts.skip,
      take: opts.take ?? 100,
    });
  },

  /** Most recent N messages, oldest-first — the shape an AI context builder wants. */
  async recentForConversation(businessId: string, conversationId: string, limit = 20) {
    const rows = await prisma.message.findMany({
      where: { businessId, conversationId },
      orderBy: { createdAt: "desc" },
      take: limit,
    });
    return rows.reverse();
  },
};

// Re-exported for convenience where callers need both in one place.
export { conversationRepository };
