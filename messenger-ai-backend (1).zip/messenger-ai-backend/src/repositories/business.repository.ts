import { prisma } from "../db/client";

/**
 * Business is the tenant root, not a business-*owned* row — the
 * businessId-scoping convention in every other repository (see
 * docs/ARCHITECTURE.md "Tenant isolation") doesn't apply here because there
 * is no cross-tenant concern one level up: looking a Business up by its own
 * id or by its Messenger Page id *is* the tenant-resolution step everything
 * else depends on. This is the only repository in the project that doesn't
 * take businessId as its first argument, and that's intentional.
 */
export const businessRepository = {
  async findById(businessId: string) {
    return prisma.business.findUnique({ where: { id: businessId } });
  },

  /** The entry point for webhook business identification: Messenger Page ID
   * → Business. Never creates a Business for an unrecognized page — see
   * BusinessResolverService / requirement 2 ("If the page is unknown: do
   * not create random business records"). */
  async findByMessengerPageId(messengerPageId: string) {
    return prisma.business.findUnique({ where: { messengerPageId } });
  },
};
