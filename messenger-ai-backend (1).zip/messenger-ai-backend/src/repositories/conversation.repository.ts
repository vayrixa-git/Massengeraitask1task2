import { prisma } from "../db/client";
import type { ConversationStatus } from "@prisma/client";

export const conversationRepository = {
  async create(businessId: string, customerId: string) {
    return prisma.conversation.create({
      data: { businessId, customerId },
    });
  },

  async findById(businessId: string, conversationId: string) {
    return prisma.conversation.findFirst({
      where: { id: conversationId, businessId },
    });
  },

  /** The conversation a new inbound message should attach to — the most
   * recently active OPEN/PENDING one for this customer, or none. */
  async findActiveForCustomer(businessId: string, customerId: string) {
    return prisma.conversation.findFirst({
      where: {
        businessId,
        customerId,
        status: { in: ["OPEN", "PENDING"] },
      },
      orderBy: { lastMessageAt: "desc" },
    });
  },

  async findOrCreateActiveForCustomer(businessId: string, customerId: string) {
    const existing = await this.findActiveForCustomer(businessId, customerId);
    if (existing) return existing;
    return this.create(businessId, customerId);
  },

  async touchLastMessageAt(businessId: string, conversationId: string, at: Date = new Date()) {
    return prisma.conversation.updateMany({
      where: { id: conversationId, businessId },
      data: { lastMessageAt: at },
    });
  },

  async setStatus(businessId: string, conversationId: string, status: ConversationStatus) {
    return prisma.conversation.updateMany({
      where: { id: conversationId, businessId },
      data: { status },
    });
  },

  async setSummary(businessId: string, conversationId: string, summary: string) {
    return prisma.conversation.updateMany({
      where: { id: conversationId, businessId },
      data: { summary },
    });
  },

  async listForCustomer(
    businessId: string,
    customerId: string,
    opts: { skip?: number; take?: number } = {}
  ) {
    return prisma.conversation.findMany({
      where: { businessId, customerId },
      orderBy: { lastMessageAt: "desc" },
      skip: opts.skip,
      take: opts.take ?? 20,
    });
  },
};
