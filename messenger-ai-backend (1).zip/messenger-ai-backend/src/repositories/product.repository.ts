import { prisma } from "../db/client";
import type { Prisma } from "@prisma/client";

export const productRepository = {
  async create(
    businessId: string,
    input: {
      name: string;
      description?: string | null;
      price: number | string;
      currency?: string;
      sku?: string | null;
      stockQuantity?: number;
      isActive?: boolean;
    }
  ) {
    return prisma.product.create({
      data: {
        businessId,
        name: input.name,
        description: input.description ?? null,
        price: input.price as unknown as Prisma.Decimal,
        currency: input.currency ?? "BDT",
        sku: input.sku ?? null,
        stockQuantity: input.stockQuantity ?? 0,
        isActive: input.isActive ?? true,
      },
    });
  },

  async findById(businessId: string, productId: string) {
    return prisma.product.findFirst({ where: { id: productId, businessId } });
  },

  async listActive(businessId: string, opts: { skip?: number; take?: number } = {}) {
    return prisma.product.findMany({
      where: { businessId, isActive: true },
      orderBy: { createdAt: "desc" },
      skip: opts.skip,
      take: opts.take ?? 50,
    });
  },

  async adjustStock(businessId: string, productId: string, delta: number) {
    // increment/decrement is atomic at the DB level — safe under concurrent orders.
    const { count } = await prisma.product.updateMany({
      where: { id: productId, businessId },
      data: { stockQuantity: { increment: delta } },
    });
    return count > 0;
  },
};
