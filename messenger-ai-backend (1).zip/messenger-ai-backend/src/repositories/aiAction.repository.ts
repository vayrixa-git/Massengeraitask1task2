import { prisma } from "../db/client";
import type { AIActionStatus } from "@prisma/client";

export const aiActionRepository = {
  /** Log an intended action before it runs — status defaults to PENDING so a
   * Policy Layer (a later task) has a row to attach its ALLOW/BLOCK/
   * REQUIRE_APPROVAL decision to before anything actually executes. */
  async record(
    businessId: string,
    input: {
      actionType: string;
      reason: string;
      customerId?: string | null;
      conversationId?: string | null;
      status?: AIActionStatus;
      inputData?: Record<string, unknown>;
    }
  ) {
    return prisma.aIAction.create({
      data: {
        businessId,
        actionType: input.actionType,
        reason: input.reason,
        customerId: input.customerId ?? null,
        conversationId: input.conversationId ?? null,
        status: input.status ?? "PENDING",
        inputData: (input.inputData ?? {}) as any,
      },
    });
  },

  async markExecuted(
    businessId: string,
    actionId: string,
    resultData: Record<string, unknown>
  ) {
    const { count } = await prisma.aIAction.updateMany({
      where: { id: actionId, businessId },
      data: { status: "EXECUTED", resultData: resultData as any, executedAt: new Date() },
    });
    return count > 0;
  },

  async markStatus(
    businessId: string,
    actionId: string,
    status: AIActionStatus,
    resultData?: Record<string, unknown>
  ) {
    const { count } = await prisma.aIAction.updateMany({
      where: { id: actionId, businessId },
      data: {
        status,
        ...(resultData ? { resultData: resultData as any } : {}),
      },
    });
    return count > 0;
  },

  async listForCustomer(businessId: string, customerId: string, limit = 50) {
    return prisma.aIAction.findMany({
      where: { businessId, customerId },
      orderBy: { createdAt: "desc" },
      take: limit,
    });
  },

  async listPendingApproval(businessId: string) {
    return prisma.aIAction.findMany({
      where: { businessId, status: "PENDING" },
      orderBy: { createdAt: "asc" },
    });
  },
};
