import { prisma } from "../db/client";
import type { KnowledgeType, KnowledgeSource } from "@prisma/client";

export const knowledgeRepository = {
  async create(
    businessId: string,
    input: {
      type: KnowledgeType;
      title: string;
      content: string;
      source?: KnowledgeSource;
      priority?: number;
      isActive?: boolean;
    }
  ) {
    return prisma.businessKnowledge.create({
      data: {
        businessId,
        type: input.type,
        title: input.title,
        content: input.content,
        source: input.source ?? "BUSINESS_OWNER",
        priority: input.priority ?? 0,
        isActive: input.isActive ?? true,
      },
    });
  },

  /** Active knowledge entries an AI context builder should include, highest
   * priority first — this is how "reliable business-provided information"
   * (source=BUSINESS_OWNER, higher priority) wins over AI-generated notes. */
  async listActive(businessId: string, type?: KnowledgeType) {
    return prisma.businessKnowledge.findMany({
      where: { businessId, isActive: true, ...(type ? { type } : {}) },
      orderBy: [{ priority: "desc" }, { updatedAt: "desc" }],
    });
  },

  async deactivate(businessId: string, knowledgeId: string) {
    const { count } = await prisma.businessKnowledge.updateMany({
      where: { id: knowledgeId, businessId },
      data: { isActive: false },
    });
    return count > 0;
  },
};
