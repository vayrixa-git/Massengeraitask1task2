import { prisma } from "../db/client";
import { isUniqueConstraintError } from "../lib/prismaErrors";
import type { Message } from "@prisma/client";

/**
 * WebhookEvent is the idempotency ledger for every inbound Messenger webhook
 * event — not just ones that produce a Message. Facebook redelivers whole
 * webhook batches on timeout/non-2xx, so the *same* postback, delivery
 * receipt, or read receipt can arrive more than once too; without a ledger
 * for those, only message events would be protected.
 *
 * Both methods below rely on the DB's own unique constraint
 * (`@@unique([businessId, dedupeKey])`) to decide "already processed",
 * not a check-then-insert read — that's what makes this safe under genuine
 * concurrent duplicate delivery (two requests racing to insert the same key
 * can't both win; Postgres serializes it and the loser gets a unique
 * violation, which is caught and treated as "duplicate", not an error).
 */
export const webhookEventRepository = {
  /** Fast-path read for the common case (Facebook redelivering a batch it's
   * already seen) — purely an optimization to skip redundant work; it is
   * NOT what makes dedup correct (see file header). Safe to skip/race. */
  async findByDedupeKey(businessId: string, dedupeKey: string) {
    return prisma.webhookEvent.findUnique({
      where: { businessId_dedupeKey: { businessId, dedupeKey } },
    });
  },

  /** For non-message events (postback/delivery/read/unsupported): records
   * the event with no associated Message. Returns the created row, or null
   * if this exact event was already recorded. */
  async tryRecordEvent(businessId: string, dedupeKey: string, eventType: string) {
    try {
      return await prisma.webhookEvent.create({
        data: { businessId, dedupeKey, eventType },
      });
    } catch (err) {
      if (isUniqueConstraintError(err)) return null;
      throw err;
    }
  },

  /**
   * For message events: creates the inbound Message, bumps
   * conversation.lastMessageAt, and records the WebhookEvent ledger row, all
   * three in ONE transaction. That atomicity is deliberate — recording the
   * ledger row as a separate step *after* message creation would leave a
   * window where a crash mid-processing loses the message forever (ledger
   * says "duplicate, skip" on redelivery, but no message was ever actually
   * stored). Committing them together means either both exist or neither
   * does, so a retry after a genuine failure correctly reprocesses from
   * scratch instead of silently dropping the message.
   *
   * Returns `created: true` with the new Message, or `created: false` with
   * the ALREADY-EXISTING Message if this exact webhook event (by dedupeKey)
   * or this exact Messenger mid (by externalMessageId) was already
   * processed — either constraint firing means "duplicate", handled
   * identically.
   */
  async recordIncomingMessage(
    businessId: string,
    input: {
      dedupeKey: string;
      conversationId: string;
      customerId: string;
      content: string;
      externalMessageId?: string | null;
      metadata?: Record<string, unknown>;
    }
  ): Promise<{ message: Message; created: boolean }> {
    try {
      const message = await prisma.$transaction(async (tx) => {
        const created = await tx.message.create({
          data: {
            businessId,
            conversationId: input.conversationId,
            customerId: input.customerId,
            senderType: "CUSTOMER",
            content: input.content,
            externalMessageId: input.externalMessageId ?? null,
            metadata: (input.metadata ?? {}) as any,
          },
        });

        await tx.conversation.update({
          where: { id: input.conversationId, businessId },
          data: { lastMessageAt: created.createdAt },
        });

        await tx.webhookEvent.create({
          data: {
            businessId,
            dedupeKey: input.dedupeKey,
            eventType: "message",
            messageId: created.id,
          },
        });

        return created;
      });

      return { message, created: true };
    } catch (err) {
      if (!isUniqueConstraintError(err)) throw err;

      const existing = await this.findExistingForDuplicate(businessId, input.dedupeKey, input.externalMessageId);
      if (existing) return { message: existing, created: false };

      // A unique violation fired but we couldn't find the row it belongs
      // to (shouldn't happen) — surface the original error rather than
      // silently treating an unexplained conflict as success.
      throw err;
    }
  },

  /** Looks up the Message a duplicate delivery's ledger row (or mid) already
   * points to, trying the ledger first (authoritative for this exact event)
   * and falling back to externalMessageId (covers the rarer case where the
   * mid collided but the dedupeKey somehow didn't, e.g. a hand-crafted
   * retry with a new timestamp reusing an old mid). */
  async findExistingForDuplicate(businessId: string, dedupeKey: string, externalMessageId?: string | null) {
    const ledgerRow = await prisma.webhookEvent.findUnique({
      where: { businessId_dedupeKey: { businessId, dedupeKey } },
    });
    if (ledgerRow?.messageId) {
      const viaLedger = await prisma.message.findFirst({
        where: { id: ledgerRow.messageId, businessId },
      });
      if (viaLedger) return viaLedger;
    }

    if (externalMessageId) {
      return prisma.message.findFirst({ where: { businessId, externalMessageId } });
    }

    return null;
  },
};
