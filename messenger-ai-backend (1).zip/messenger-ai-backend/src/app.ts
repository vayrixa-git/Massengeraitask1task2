import express, { type Express, type Request, type Response, type NextFunction } from "express";
import { messengerWebhookRouter } from "./routes/messengerWebhook.routes";
import { logger } from "./lib/logger";

/**
 * Builds the app without starting a listener — server.ts does that. Kept
 * separate so tests can `import { createApp } from "./app"` and drive it
 * with supertest directly, with no real port/socket involved.
 */
export function createApp(): Express {
  const app = express();

  app.get("/health", (_req: Request, res: Response) => {
    res.status(200).json({ ok: true });
  });

  app.use("/webhooks/messenger", messengerWebhookRouter);

  // Catch-all — anything that reaches here is a route this app doesn't
  // have, not a webhook concern.
  app.use((_req: Request, res: Response) => {
    res.sendStatus(404);
  });

  // Central error handler. Must be registered last, and must take exactly
  // 4 args for Express to recognize it as an error handler. Never leaks a
  // stack trace or raw error message to the caller (requirement 10/14).
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
    logger.error("http.unhandled_error", {
      path: req.path,
      error: err instanceof Error ? err.message : String(err),
    });
    if (res.headersSent) return;
    res.status(500).json({ error: "internal_error" });
  });

  return app;
}
