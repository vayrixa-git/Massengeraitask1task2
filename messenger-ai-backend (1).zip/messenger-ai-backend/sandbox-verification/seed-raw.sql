-- Raw-SQL equivalent of prisma/seed.ts, run here only because Prisma Client
-- can't be generated in this sandbox. Same fixture data prisma/seed.ts
-- creates when run normally with `npm run db:seed`.

INSERT INTO "Business" (id, name, slug, timezone, "messengerPageId", "updatedAt")
VALUES ('biz_rangoli', 'Rangoli Cosmetics', 'rangoli-cosmetics', 'Asia/Dhaka', 'demo-page-123456', now());

INSERT INTO "Product" (id, "businessId", name, description, price, currency, sku, "stockQuantity", "updatedAt") VALUES
('prod_lipstick', 'biz_rangoli', 'ম্যাট লিপস্টিক', 'Long-lasting matte lipstick', 450, 'BDT', 'LIP-MATTE-01', 3, now()),
('prod_facewash', 'biz_rangoli', 'ফেসওয়াশ', 'Daily brightening face wash', 350, 'BDT', 'FACE-WASH-01', 20, now()),
('prod_kajol', 'biz_rangoli', 'কাজল', 'Smudge-proof kajol', 150, 'BDT', 'KAJOL-01', 0, now());

INSERT INTO "BusinessKnowledge" (id, "businessId", type, source, title, content, priority, "updatedAt") VALUES
('know_delivery', 'biz_rangoli', 'DELIVERY_POLICY', 'BUSINESS_OWNER', 'Delivery inside Dhaka', 'Delivery within Dhaka takes 1-2 business days, cash on delivery available.', 10, now()),
('know_return', 'biz_rangoli', 'RETURN_POLICY', 'BUSINESS_OWNER', 'Returns', 'Unused items in original packaging can be returned within 7 days.', 10, now()),
('know_payment', 'biz_rangoli', 'FAQ', 'BUSINESS_OWNER', 'Payment methods', 'We accept bKash, Nagad, and cash on delivery.', 5, now());

INSERT INTO "Customer" (id, "businessId", "messengerPsid", name, phone, "updatedAt") VALUES
('cust_nusrat', 'biz_rangoli', 'psid-1001', 'Nusrat Jahan', '+8801710000001', now()),
('cust_rakibul', 'biz_rangoli', 'psid-1002', 'Rakibul Islam', '+8801710000002', now()),
('cust_farhana', 'biz_rangoli', 'psid-1003', 'Farhana Akter', '+8801710000003', now());

INSERT INTO "Conversation" (id, "businessId", "customerId", status, "updatedAt") VALUES
('convo_nusrat', 'biz_rangoli', 'cust_nusrat', 'OPEN', now()),
('convo_rakibul', 'biz_rangoli', 'cust_rakibul', 'OPEN', now()),
('convo_farhana', 'biz_rangoli', 'cust_farhana', 'OPEN', now());

INSERT INTO "Message" (id, "businessId", "conversationId", "customerId", "senderType", content, metadata) VALUES
('msg_nusrat_1', 'biz_rangoli', 'convo_nusrat', 'cust_nusrat', 'CUSTOMER', 'আসসালামু আলাইকুম, ম্যাট লিপস্টিক এর দাম কত?', '{"mid":"mid-1001-1","platform":"messenger"}'),
('msg_nusrat_2', 'biz_rangoli', 'convo_nusrat', 'cust_nusrat', 'AI', 'ওয়ালাইকুম আসসালাম! ম্যাট লিপস্টিক এর দাম ৪৫০ টাকা।', '{"mid":"mid-1001-2"}'),
('msg_rakibul_1', 'biz_rangoli', 'convo_rakibul', 'cust_rakibul', 'CUSTOMER', 'আসসালামু আলাইকুম, ম্যাট লিপস্টিক এর দাম কত?', '{"mid":"mid-1002-1"}'),
('msg_farhana_1', 'biz_rangoli', 'convo_farhana', 'cust_farhana', 'CUSTOMER', 'আসসালামু আলাইকুম, ম্যাট লিপস্টিক এর দাম কত?', '{"mid":"mid-1003-1"}');

UPDATE "Conversation" SET "lastMessageAt" = now() WHERE id IN ('convo_nusrat','convo_rakibul','convo_farhana');

INSERT INTO "CustomerMemory" (id, "businessId", "customerId", content, "memoryType", importance, confidence, source, "updatedAt") VALUES
('mem_nusrat', 'biz_rangoli', 'cust_nusrat', 'Asked about ম্যাট লিপস্টিক pricing', 'PURCHASE_INTENT', 3, 0.9, 'CONVERSATION_SUMMARY', now()),
('mem_rakibul', 'biz_rangoli', 'cust_rakibul', 'Asked about ম্যাট লিপস্টিক pricing', 'PURCHASE_INTENT', 3, 0.9, 'CONVERSATION_SUMMARY', now()),
('mem_farhana', 'biz_rangoli', 'cust_farhana', 'Asked about ম্যাট লিপস্টিক pricing', 'PURCHASE_INTENT', 3, 0.9, 'CONVERSATION_SUMMARY', now());

INSERT INTO "Order" (id, "businessId", "customerId", status, "totalAmount", currency, "updatedAt")
VALUES ('order_nusrat_1', 'biz_rangoli', 'cust_nusrat', 'CONFIRMED', 450, 'BDT', now());

INSERT INTO "OrderItem" (id, "orderId", "productId", quantity, "unitPrice")
VALUES ('orderitem_1', 'order_nusrat_1', 'prod_lipstick', 1, 450);

INSERT INTO "AIAction" (id, "businessId", "customerId", "actionType", status, reason, "inputData", "resultData", "executedAt") VALUES
('action_1', 'biz_rangoli', 'cust_nusrat', 'SEND_REPLY', 'EXECUTED', 'Answered a pricing question using BusinessKnowledge + Product data', '{"question":"ম্যাট লিপস্টিক price?"}', '{"replied":true}', now()),
('action_2', 'biz_rangoli', 'cust_nusrat', 'APPLY_DISCOUNT', 'PENDING', 'Customer asked for a bulk discount above the 15% auto-approve threshold', '{"requestedDiscountPercent":25}', NULL, NULL);
