/**
 * SANDBOX-ONLY VERIFICATION — NOT PART OF THE APPLICATION.
 *
 * `prisma generate` needs to download engine binaries from
 * binaries.prisma.sh, which this sandbox's network allowlist blocks (see
 * docs/ARCHITECTURE.md "Environment limitation: Prisma engine binaries").
 * That means `@prisma/client` has no working generated client here, so
 * nothing in src/ or tests/ (which correctly use @prisma/client, as they
 * should for the real deployment) can actually execute in this sandbox.
 *
 * This script exercises the same operations the repositories/services and
 * Vitest suite perform — using the plain `pg` driver instead of Prisma
 * Client — directly against the same live Postgres 16 + pgvector database
 * the migration was applied to. It exists only to prove, for real, that the
 * schema/migration/query patterns are correct in an environment where the
 * Prisma Client path is blocked. Delete it once Prisma Client works
 * normally (any environment with normal internet access).
 */
import { Client } from "pg";

const log = (msg: string) => console.log(`  ${msg}`);
let passed = 0;
let failed = 0;

function assert(condition: unknown, message: string) {
  if (condition) {
    passed++;
    log(`OK  - ${message}`);
  } else {
    failed++;
    log(`FAIL - ${message}`);
  }
}

async function main() {
  const client = new Client({
    connectionString: "postgresql://postgres:postgres@localhost:5432/messenger_ai",
  });
  await client.connect();

  console.log("1. Tenant + customer + conversation + message");
  const bizA = await client.query(
    `INSERT INTO "Business" (id, name, slug, "updatedAt") VALUES ($1,$2,$3,now()) RETURNING id`,
    ["biz_a_verify", "Verify Business A", "verify-biz-a"]
  );
  const bizB = await client.query(
    `INSERT INTO "Business" (id, name, slug, "updatedAt") VALUES ($1,$2,$3,now()) RETURNING id`,
    ["biz_b_verify", "Verify Business B", "verify-biz-b"]
  );
  const businessAId = bizA.rows[0].id;
  const businessBId = bizB.rows[0].id;

  const cust = await client.query(
    `INSERT INTO "Customer" (id, "businessId", "messengerPsid", name, "updatedAt")
     VALUES ($1,$2,$3,$4, now()) RETURNING id`,
    ["cust_verify_1", businessAId, "psid-verify-1", "Verify Customer"]
  );
  const customerId = cust.rows[0].id;

  const convo = await client.query(
    `INSERT INTO "Conversation" (id, "businessId", "customerId", "updatedAt")
     VALUES ($1,$2,$3, now()) RETURNING id, "lastMessageAt"`,
    ["convo_verify_1", businessAId, customerId]
  );
  const conversationId = convo.rows[0].id;
  const lastMessageBefore = convo.rows[0].lastMessageAt;

  await client.query(
    `INSERT INTO "Message" (id, "businessId", "conversationId", "customerId", "senderType", content)
     VALUES ($1,$2,$3,$4,'CUSTOMER',$5)`,
    ["msg_verify_1", businessAId, conversationId, customerId, "Is the lipstick in stock?"]
  );
  await client.query(
    `UPDATE "Conversation" SET "lastMessageAt" = now() WHERE id = $1`,
    [conversationId]
  );
  const convoAfter = await client.query(`SELECT "lastMessageAt" FROM "Conversation" WHERE id = $1`, [conversationId]);
  assert(
    new Date(convoAfter.rows[0].lastMessageAt).getTime() >= new Date(lastMessageBefore).getTime(),
    "message creation bumps conversation.lastMessageAt"
  );

  console.log("2. Tenant isolation");
  const crossTenantRead = await client.query(
    `SELECT * FROM "Customer" WHERE id = $1 AND "businessId" = $2`,
    [customerId, businessBId]
  );
  assert(crossTenantRead.rowCount === 0, "business B cannot read business A's customer");

  console.log("3. Memory lifecycle: save, supersede, invalidate, expire");
  await client.query(
    `INSERT INTO "CustomerMemory" (id, "businessId", "customerId", content, "memoryType", importance, "updatedAt")
     VALUES ($1,$2,$3,$4,'PREFERENCE',4, now())`,
    ["mem_verify_1", businessAId, customerId, "Prefers matte lipstick"]
  );
  await client.query(
    `INSERT INTO "CustomerMemory" (id, "businessId", "customerId", content, "memoryType", importance, "supersedesId", "updatedAt")
     VALUES ($1,$2,$3,$4,'PREFERENCE',4,$5, now())`,
    ["mem_verify_2", businessAId, customerId, "Prefers matte lipstick, budget under 500 BDT", "mem_verify_1"]
  );
  await client.query(`UPDATE "CustomerMemory" SET status = 'SUPERSEDED' WHERE id = $1`, ["mem_verify_1"]);

  const oldMem = await client.query(`SELECT status FROM "CustomerMemory" WHERE id = $1`, ["mem_verify_1"]);
  assert(oldMem.rows[0].status === "SUPERSEDED", "old memory marked SUPERSEDED after update");

  const activeAfterSupersede = await client.query(
    `SELECT id FROM "CustomerMemory" WHERE "businessId" = $1 AND "customerId" = $2 AND status = 'ACTIVE'`,
    [businessAId, customerId]
  );
  assert(
    activeAfterSupersede.rows.some((r) => r.id === "mem_verify_2"),
    "replacement memory is ACTIVE"
  );

  await client.query(`UPDATE "CustomerMemory" SET status = 'INVALIDATED' WHERE id = $1`, ["mem_verify_2"]);
  const activeAfterInvalidate = await client.query(
    `SELECT id FROM "CustomerMemory" WHERE "businessId" = $1 AND "customerId" = $2 AND status = 'ACTIVE'`,
    [businessAId, customerId]
  );
  assert(
    !activeAfterInvalidate.rows.some((r) => r.id === "mem_verify_2"),
    "invalidated memory excluded from ACTIVE set"
  );

  await client.query(
    `INSERT INTO "CustomerMemory" (id, "businessId", "customerId", content, "expiresAt", "updatedAt")
     VALUES ($1,$2,$3,$4, now() - interval '1 day', now())`,
    ["mem_verify_3", businessAId, customerId, "Should already be expired"]
  );
  const expireResult = await client.query(
    `UPDATE "CustomerMemory" SET status = 'EXPIRED'
     WHERE "businessId" = $1 AND status = 'ACTIVE' AND "expiresAt" < now() RETURNING id`,
    [businessAId]
  );
  assert(expireResult.rows.some((r) => r.id === "mem_verify_3"), "past-expiresAt memory gets EXPIRED");

  console.log("4. pgvector: embedding storage + cosine similarity search");
  const dim = 1536; // the column is fixed at vector(1536) — must match exactly
  await client.query(
    `INSERT INTO "CustomerMemory" (id, "businessId", "customerId", content, "updatedAt")
     VALUES ($1,$2,$3,$4, now())`,
    ["mem_verify_vec_close", businessAId, customerId, "close vector memory"]
  );
  await client.query(
    `INSERT INTO "CustomerMemory" (id, "businessId", "customerId", content, "updatedAt")
     VALUES ($1,$2,$3,$4, now())`,
    ["mem_verify_vec_far", businessAId, customerId, "far vector memory"]
  );
  const closeVec = `[${Array(dim).fill(0.1).join(",")}]`;
  const farVec = `[${Array(dim).fill(-0.9).join(",")}]`;
  const queryVec = `[${Array(dim).fill(0.1).join(",")}]`;
  await client.query(`UPDATE "CustomerMemory" SET embedding = $1::text::vector WHERE id = $2`, [
    closeVec,
    "mem_verify_vec_close",
  ]);
  await client.query(`UPDATE "CustomerMemory" SET embedding = $1::text::vector WHERE id = $2`, [
    farVec,
    "mem_verify_vec_far",
  ]);
  const nn = await client.query(
    `SELECT id, (embedding <=> $1::text::vector) AS distance
     FROM "CustomerMemory"
     WHERE "businessId" = $2 AND embedding IS NOT NULL
     ORDER BY distance ASC LIMIT 1`,
    [queryVec, businessAId]
  );
  assert(nn.rows[0]?.id === "mem_verify_vec_close", "cosine nearest-neighbor query returns the closer vector first");

  console.log("5. Products: SKU unique per business, not globally");
  await client.query(
    `INSERT INTO "Product" (id, "businessId", name, price, sku, "updatedAt")
     VALUES ($1,$2,$3,$4,$5, now())`,
    ["prod_verify_a", businessAId, "Shared SKU Product A", 100, "SHARED-SKU-VERIFY"]
  );
  await client.query(
    `INSERT INTO "Product" (id, "businessId", name, price, sku, "updatedAt")
     VALUES ($1,$2,$3,$4,$5, now())`,
    ["prod_verify_b", businessBId, "Shared SKU Product B", 200, "SHARED-SKU-VERIFY"]
  );
  let duplicateSkuRejected = false;
  try {
    await client.query(
      `INSERT INTO "Product" (id, "businessId", name, price, sku, "updatedAt")
       VALUES ($1,$2,$3,$4,$5, now())`,
      ["prod_verify_a_dup", businessAId, "Duplicate within same business", 300, "SHARED-SKU-VERIFY"]
    );
  } catch {
    duplicateSkuRejected = true;
  }
  assert(duplicateSkuRejected, "duplicate SKU within the SAME business is rejected by the unique constraint");

  console.log("6. Orders + order items");
  await client.query(
    `INSERT INTO "Order" (id, "businessId", "customerId", "totalAmount", "updatedAt")
     VALUES ($1,$2,$3,$4, now())`,
    ["order_verify_1", businessAId, customerId, 100]
  );
  await client.query(
    `INSERT INTO "OrderItem" (id, "orderId", "productId", quantity, "unitPrice")
     VALUES ($1,$2,$3,$4,$5)`,
    ["orderitem_verify_1", "order_verify_1", "prod_verify_a", 1, 100]
  );
  const orderItems = await client.query(`SELECT * FROM "OrderItem" WHERE "orderId" = $1`, ["order_verify_1"]);
  assert(orderItems.rowCount === 1, "order item linked to order and product");

  console.log("7. AIAction audit trail");
  await client.query(
    `INSERT INTO "AIAction" (id, "businessId", "customerId", "actionType", status, reason, "inputData")
     VALUES ($1,$2,$3,'APPLY_DISCOUNT','PENDING',$4,$5)`,
    ["action_verify_1", businessAId, customerId, "Requested 25% off, above auto-approve threshold", JSON.stringify({ requestedDiscountPercent: 25 })]
  );
  await client.query(
    `UPDATE "AIAction" SET status = 'EXECUTED', "executedAt" = now(), "resultData" = $1 WHERE id = $2`,
    [JSON.stringify({ approved: true }), "action_verify_1"]
  );
  const action = await client.query(`SELECT status, "executedAt" FROM "AIAction" WHERE id = $1`, ["action_verify_1"]);
  assert(action.rows[0].status === "EXECUTED" && action.rows[0].executedAt !== null, "AI action recorded and marked executed");

  console.log("8. Cascade delete: deleting a Business cascades to all owned rows");
  // OrderItem->Product is ON DELETE RESTRICT by design (protects order history
  // from an accidental single-product delete — see docs/ARCHITECTURE.md
  // "Deleting a business with order history"). RESTRICT is checked
  // immediately, not deferred, so a full tenant deletion must clear
  // OrderItem/Order itself first; Postgres's own cascade ordering across the
  // Order and Product branches isn't guaranteed to do this for us.
  await client.query(`DELETE FROM "OrderItem" WHERE "orderId" IN (SELECT id FROM "Order" WHERE "businessId" = $1)`, [businessAId]);
  await client.query(`DELETE FROM "Order" WHERE "businessId" = $1`, [businessAId]);
  await client.query(`DELETE FROM "Business" WHERE id = $1`, [businessAId]);
  const orphanCustomers = await client.query(`SELECT * FROM "Customer" WHERE "businessId" = $1`, [businessAId]);
  const orphanMemories = await client.query(`SELECT * FROM "CustomerMemory" WHERE "businessId" = $1`, [businessAId]);
  const orphanActions = await client.query(`SELECT * FROM "AIAction" WHERE "businessId" = $1`, [businessAId]);
  assert(orphanCustomers.rowCount === 0, "cascade deleted customers");
  assert(orphanMemories.rowCount === 0, "cascade deleted memories");
  assert(orphanActions.rowCount === 0, "cascade deleted AI actions");

  // cleanup business B fixture
  await client.query(`DELETE FROM "Business" WHERE id = $1`, [businessBId]);

  await client.end();

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

main().catch((err) => {
  console.error("Verification script crashed:", err);
  process.exit(1);
});
